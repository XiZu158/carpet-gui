package dev.carpetgui.client;

import dev.carpetgui.model.RuleView;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;

import java.util.List;
import java.util.stream.Collectors;

/** Edits a draft; only an acknowledged server snapshot changes the displayed current value. */
public final class RuleEditScreen extends Screen {
    private final RulesScreen parent;
    private final ClientState state = CarpetGuiClient.STATE;
    private RuleView rule;
    private String draft;
    private int left;
    private int contentWidth;
    private int descriptionScroll;
    private List<FormattedCharSequence> description = List.of();
    private EditBox input;
    private Button choice;
    private Button apply;
    private Button reset;
    private List<String> choices = List.of();

    public RuleEditScreen(RulesScreen parent, RuleView rule) {
        super(Component.literal(RuleText.name(rule)));
        this.parent = parent;
        this.rule = rule;
        this.draft = rule.value();
    }

    @Override
    protected void init() {
        contentWidth = Math.min(640, width - 32);
        left = (width - contentWidth) / 2;
        description = font.split(Component.literal(RuleText.description(rule)), contentWidth - 12);
        descriptionScroll = Math.clamp(descriptionScroll, 0, Math.max(0, description.size() - visibleDescriptionLines()));
        boolean booleanRule = rule.type().equalsIgnoreCase("boolean") || rule.type().equalsIgnoreCase("bool")
                || rule.type().equals("java.lang.Boolean");
        choices = booleanRule ? List.of("false", "true") : rule.strict() ? rule.options() : List.of();
        int valueWidth = Math.max(80, contentWidth - 116);
        input = null;
        choice = null;
        if (!choices.isEmpty()) {
            choice = addRenderableWidget(Button.builder(Component.literal(draft), button -> {
                draft = choices.get((choices.indexOf(draft) + 1) % choices.size());
                button.setMessage(Component.literal(draft));
            }).bounds(left, height - 102, valueWidth, 20)
                    .tooltip(Tooltip.create(Component.literal(String.join(", ", choices)))).build());
        } else {
            input = addRenderableWidget(new EditBox(font, left, height - 102, valueWidth, 20,
                    Component.translatable("carpet_gui.value")));
            input.setMaxLength(4096);
            input.setValue(draft);
            input.setResponder(value -> draft = value);
            input.setHint(Component.literal(rule.type()));
            if (!rule.options().isEmpty()) {
                input.setTooltip(Tooltip.create(Component.translatable("carpet_gui.suggestions", String.join(", ", rule.options()))));
            }
        }
        reset = addRenderableWidget(Button.builder(Component.translatable("carpet_gui.default"), button -> {
            draft = rule.defaultValue();
            if (input != null) input.setValue(draft);
            if (choice != null) choice.setMessage(Component.literal(draft));
        }).bounds(left + contentWidth - 110, height - 102, 110, 20)
                .tooltip(Tooltip.create(Component.translatable("carpet_gui.default_hint"))).build());
        int half = (contentWidth - 8) / 2;
        apply = addRenderableWidget(Button.builder(Component.translatable("carpet_gui.apply"), button -> state.apply(rule, draft))
                .bounds(left, height - 55, half, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("gui.back"), button -> onClose())
                .bounds(left + half + 8, height - 55, contentWidth - half - 8, 20).build());
        updateEnabled();
    }

    private int visibleDescriptionLines() {
        return Math.max(1, (height - 214) / font.lineHeight);
    }

    @Override
    public Component getTitle() {
        return rule == null ? super.getTitle() : Component.literal(RuleText.name(rule));
    }

    @Override
    public Component getNarrationMessage() {
        return Component.literal(RuleText.name(rule) + ", " + rule.manager() + ":" + rule.name());
    }

    private String subtitle() {
        return rule.manager() + ":" + rule.name() + " · " + rule.categories().stream()
                .map(category -> RuleText.category(rule.manager(), category)).collect(Collectors.joining(", "));
    }

    private void updateEnabled() {
        RuleView latest = state.find(rule.manager(), rule.name());
        if (latest != null) rule = latest;
        boolean editable = latest != null && state.canEdit() && !rule.locked() && !state.busy();
        // Saving the current value is useful after a temporary /carpet command change.
        apply.active = editable;
        reset.active = editable;
        if (input != null) input.setEditable(editable);
        if (choice != null) choice.active = editable;
    }

    @Override
    public void tick() {
        if (minecraft.level == null) { minecraft.setScreen(null); return; }
        updateEnabled();
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontal, double vertical) {
        if (mouseX >= left && mouseX <= left + contentWidth && mouseY >= 84 && mouseY < height - 121) {
            descriptionScroll = Math.clamp(descriptionScroll - (int) Math.signum(vertical), 0,
                    Math.max(0, description.size() - visibleDescriptionLines()));
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontal, vertical);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        graphics.fill(left - 8, 6, left + contentWidth + 8, height - 4, 0xD0141C24);
        graphics.centeredText(font, font.plainSubstrByWidth(getTitle().getString(), contentWidth), width / 2, 14, 0xFF70E3CD);
        drawClipped(graphics, Component.literal(subtitle()), 32, 0xFF93A9B8);
        drawClipped(graphics, Component.translatable("carpet_gui.current", rule.value()), 49, 0xFFE6EDF3);
        drawClipped(graphics, Component.translatable("carpet_gui.default_value", rule.defaultValue(), rule.type()), 63, 0xFFBFCAD3);
        graphics.fill(left, 81, left + contentWidth, height - 121, 0x442A3844);
        graphics.enableScissor(left + 3, 84, left + contentWidth - 3, height - 123);
        for (int line = 0; line < visibleDescriptionLines() && descriptionScroll + line < description.size(); line++) {
            graphics.text(font, description.get(descriptionScroll + line), left + 6, 85 + line * font.lineHeight, 0xFFE6EDF3);
        }
        graphics.disableScissor();
        if (description.size() > visibleDescriptionLines()) {
            graphics.text(font, Component.translatable("carpet_gui.scroll"), left, height - 120, 0xFF93A9B8);
        }
        String notice = rule.locked() ? "carpet_gui.locked" : !state.canEdit() ? "carpet_gui.readonly_hint" : "carpet_gui.persist_hint";
        drawClipped(graphics, Component.translatable(notice), height - 73, 0xFFFFD075);
        super.extractRenderState(graphics, mouseX, mouseY, partialTick);
        drawClipped(graphics, state.status(), height - 23, 0xFFBFCAD3);
        if (mouseY >= height - 26) graphics.setTooltipForNextFrame(font, state.status(), mouseX, mouseY);
        if (mouseX >= left && mouseX <= left + contentWidth && mouseY >= 12 && mouseY <= 42) {
            graphics.setTooltipForNextFrame(font, Component.literal(RuleText.name(rule) + "\n" + subtitle()), mouseX, mouseY);
        }
        if (mouseY >= 45 && mouseY <= 75) {
            graphics.setTooltipForNextFrame(font, Component.literal(RuleText.name(rule) + "\n" + rule.manager() + ":" + rule.name() + "\n"
                    + Component.translatable("carpet_gui.current", rule.value()).getString() + "\n"
                    + Component.translatable("carpet_gui.default_value", rule.defaultValue(), rule.type()).getString()), mouseX, mouseY);
        }
    }

    private void drawClipped(GuiGraphicsExtractor graphics, Component text, int y, int color) {
        graphics.text(font, font.plainSubstrByWidth(text.getString(), contentWidth), left, y, color);
    }

    @Override public void onClose() { minecraft.setScreen(parent); }
    @Override public boolean isPauseScreen() { return false; }
}
