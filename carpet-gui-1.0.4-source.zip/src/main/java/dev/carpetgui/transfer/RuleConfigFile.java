package dev.carpetgui.transfer;

import dev.carpetgui.model.RuleActivity;
import dev.carpetgui.model.RuleView;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** The existing UTF-8 export format is data only; no line is executed as a command. */
public final class RuleConfigFile {
    public static final int MAX_FILE_BYTES = 4 * 1024 * 1024;
    public static final int MAX_ENTRIES = 4096;
    public record Entry(String manager, String rule, String value, int line) {
        public String id() { return manager + ":" + rule; }
    }
    public record Document(String world, List<Entry> entries) {
        public Document { entries = List.copyOf(entries); }
    }

    private RuleConfigFile() {}

    public static Document read(Path path) throws IOException {
        if (!Files.isRegularFile(path)) throw new IOException("请选择普通 TXT 文件。");
        byte[] data;
        try (var input = Files.newInputStream(path)) { data = input.readNBytes(MAX_FILE_BYTES + 1); }
        if (data.length > MAX_FILE_BYTES) throw new IOException("导入文件超过 4 MiB。");
        // The decoder rejects malformed UTF-8 instead of silently changing rule values.
        return parse(StandardCharsets.UTF_8.newDecoder().decode(ByteBuffer.wrap(data)).toString());
    }

    public static Document parse(String text) throws IOException {
        if (text.length() > MAX_FILE_BYTES || text.getBytes(StandardCharsets.UTF_8).length > MAX_FILE_BYTES)
            throw new IOException("导入文件超过 4 MiB。");
        if (text.startsWith("\uFEFF")) text = text.substring(1);
        List<Entry> entries = new ArrayList<>();
        Set<String> ids = new HashSet<>();
        String world = "";
        String[] lines = text.split("\\r\\n|\\r|\\n", -1);
        for (int index = 0; index < lines.length; index++) {
            String line = lines[index];
            if (line.isBlank()) continue;
            if (line.startsWith("# World: ")) { world = unescape(line.substring(9), index + 1); continue; }
            if (line.stripLeading().startsWith("#")) continue;
            if (line.matches("\\[[^\\]\\r\\n]+](?:[ \\t]*#.*)?")) continue;
            int separator = line.indexOf(" = ");
            if (separator < 1) throw error(index + 1, "需要“管理器:规则名 = 当前值”格式。");
            String id = unescape(line.substring(0, separator), index + 1);
            int colon = id.indexOf(':');
            if (colon < 1 || colon == id.length() - 1) throw error(index + 1, "规则缺少管理器或名称。");
            String manager = id.substring(0, colon);
            String rule = id.substring(colon + 1);
            String value = unescape(line.substring(separator + 3), index + 1);
            if (manager.length() > 256 || rule.length() > 256 || value.length() > 4096)
                throw error(index + 1, "规则标识或值过长。");
            if (!ids.add(id)) throw error(index + 1, "规则重复：" + id);
            entries.add(new Entry(manager, rule, value, index + 1));
            if (entries.size() > MAX_ENTRIES) throw error(index + 1, "一次最多导入 4096 条规则。");
        }
        return new Document(world, entries);
    }

    public static String format(String world, List<RuleView> rules, boolean enabledOnly) {
        List<RuleView> selected = rules.stream().filter(rule -> !enabledOnly || RuleActivity.isEnabled(rule))
                .sorted(Comparator.comparing(RuleView::manager).thenComparing(RuleView::name)).toList();
        StringBuilder output = new StringBuilder(enabledOnly
                ? "# Carpet GUI — enabled rules\n" : "# Carpet GUI — complete server snapshot\n");
        output.append("# World: ").append(escape(world)).append('\n');
        output.append("# Exported: ").append(LocalDateTime.now()).append('\n');
        output.append("# Rules: ").append(selected.size()).append('\n');
        output.append("# Values escape backslash, newline, carriage return, and tab.\n");
        String manager = null;
        for (RuleView rule : selected) {
            if (!rule.manager().equals(manager)) {
                output.append("\n[").append(escape(rule.manager())).append("] # ")
                        .append(escape(rule.managerName())).append('\n');
                manager = rule.manager();
            }
            output.append(escape(rule.manager())).append(':').append(escape(rule.name()))
                    .append(" = ").append(escape(rule.value())).append('\n');
        }
        return output.toString();
    }

    private static String escape(String text) {
        return text.replace("\\", "\\\\").replace("\r", "\\r").replace("\n", "\\n").replace("\t", "\\t");
    }

    private static String unescape(String text, int line) throws IOException {
        StringBuilder result = new StringBuilder();
        for (int index = 0; index < text.length(); index++) {
            char current = text.charAt(index);
            if (current != '\\') { result.append(current); continue; }
            if (++index == text.length()) throw error(line, "反斜线转义不完整。");
            result.append(switch (text.charAt(index)) {
                case '\\' -> '\\'; case 'r' -> '\r'; case 'n' -> '\n'; case 't' -> '\t';
                default -> throw error(line, "未知转义字符。");
            });
        }
        return result.toString();
    }

    private static IOException error(int line, String message) { return new IOException("第 " + line + " 行：" + message); }
}
