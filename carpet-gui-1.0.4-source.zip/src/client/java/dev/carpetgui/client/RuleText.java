package dev.carpetgui.client;

import carpet.CarpetExtension;
import carpet.CarpetServer;
import dev.carpetgui.CarpetGui;
import dev.carpetgui.model.RuleLabels;
import dev.carpetgui.model.RuleView;
import net.minecraft.client.Minecraft;
import net.minecraft.locale.Language;

import java.util.HashMap;
import java.util.Map;

/** Client-language display text. Never changes Carpet's global language or rule settings. */
public final class RuleText {
    private static Language cachedLanguage;
    private static int cachedExtensionCount = -1;
    private static Map<String, String> extensionTranslations = Map.of();

    private RuleText() {}

    public static String name(RuleView rule) {
        return RuleLabels.name(rule, RuleText::lookup);
    }

    public static String category(String manager, String category) {
        return RuleLabels.category(manager, category, RuleText::lookup);
    }

    public static String description(RuleView rule) {
        // Keep the full server description, including dynamic validator/extension extra information.
        return rule.description();
    }

    public static void invalidate() {
        cachedLanguage = null;
        cachedExtensionCount = -1;
        extensionTranslations = Map.of();
    }

    private static String lookup(String key) {
        Language language = Language.getInstance();
        if (language.has(key)) return language.getOrDefault(key);
        if (cachedLanguage != language || cachedExtensionCount != CarpetServer.extensions.size()) {
            rebuildExtensions(language);
        }
        return extensionTranslations.get(key);
    }

    private static void rebuildExtensions(Language language) {
        Map<String, String> merged = new HashMap<>();
        String selected = Minecraft.getInstance().getLanguageManager().getSelected();
        for (CarpetExtension extension : CarpetServer.extensions.toArray(CarpetExtension[]::new)) {
            try {
                merge(merged, extension.canHasTranslations("en_us"));
                if (!"en_us".equals(selected)) merge(merged, extension.canHasTranslations(selected));
            } catch (RuntimeException exception) {
                // A missing/broken optional translation must not prevent opening the rules screen.
                CarpetGui.LOGGER.warn("Cannot load {} translations for {}", selected,
                        extension.getClass().getName(), exception);
            }
        }
        extensionTranslations = Map.copyOf(merged);
        cachedLanguage = language;
        cachedExtensionCount = CarpetServer.extensions.size();
    }

    private static void merge(Map<String, String> target, Map<String, String> source) {
        if (source == null) return;
        source.forEach((key, value) -> {
            if (key == null || value == null || value.isBlank()) return;
            // Same legacy-key normalization as Carpet 26.1's translation loader.
            String normalized = key.startsWith("rule.") || key.startsWith("category.") ? "carpet." + key : key;
            target.put(normalized, value);
        });
    }
}
