package dev.carpetgui.transfer;

import dev.carpetgui.model.RuleActivity;
import dev.carpetgui.model.RuleView;
import dev.carpetgui.storage.WorldConfigStore;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Preview against the destination world's metadata. Carpet still validates each submitted value. */
public record ImportPlan(Mode mode, List<Row> rows) {
    public enum Mode { ENABLED_ONLY, ALL_VALUES }
    public enum Status { READY, MISSING, LOCKED, NOT_ENABLED, INVALID }
    public record Row(RuleConfigFile.Entry entry, RuleView target, Status status, String detail) {}
    public ImportPlan { rows = List.copyOf(rows); }

    public List<RuleConfigFile.Entry> ready() {
        return rows.stream().filter(row -> row.status() == Status.READY).map(Row::entry).toList();
    }

    public static ImportPlan create(RuleConfigFile.Document document, List<RuleView> targetRules, Mode mode) {
        Map<String, RuleView> targets = new HashMap<>();
        targetRules.forEach(rule -> targets.put(rule.manager() + ":" + rule.name(), rule));
        List<Row> rows = new ArrayList<>();
        for (var entry : document.entries()) {
            RuleView target = targets.get(entry.id());
            Status status = Status.READY;
            String detail = "";
            if (target == null) status = Status.MISSING;
            else {
                try { WorldConfigStore.validateEntry(entry.manager(), entry.rule(), entry.value()); }
                catch (IOException exception) { status = Status.INVALID; detail = exception.getMessage(); }
                if (status == Status.READY && mode == Mode.ENABLED_ONLY && !RuleActivity.isEnabledValue(target, entry.value()))
                    status = Status.NOT_ENABLED;
                if (status == Status.READY && target.locked()) status = Status.LOCKED;
            }
            rows.add(new Row(entry, target, status, detail));
        }
        return new ImportPlan(mode, rows);
    }
}
