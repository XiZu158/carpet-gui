package dev.carpetgui.server;

import carpet.CarpetServer;
import carpet.CarpetSettings;
import carpet.api.settings.CarpetRule;
import carpet.api.settings.InvalidRuleValueException;
import carpet.api.settings.RuleHelper;
import carpet.api.settings.SettingsManager;
import carpet.utils.CommandHelper;
import dev.carpetgui.CarpetGui;
import dev.carpetgui.api.CarpetGuiApi;
import dev.carpetgui.model.RuleView;
import dev.carpetgui.network.GuiProtocol;
import dev.carpetgui.storage.WorldConfigStore;
import net.fabricmc.api.EnvType;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.permissions.Permissions;
import net.minecraft.server.players.NameAndId;
import net.minecraft.world.level.storage.LevelResource;

import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.Consumer;

/** All methods are called on the logical server thread. */
public final class RuleService {
    public record SetResult(boolean success, boolean stop, String message, String value) {
        private static SetResult rejected(String message) { return new SetResult(false, false, message, ""); }
    }
    public boolean canEdit(MinecraftServer server, ServerPlayer player) {
        return server.isSingleplayerOwner(new NameAndId(player.getGameProfile()))
                || (player.permissions().hasPermission(Permissions.COMMANDS_GAMEMASTER)
                && CommandHelper.canUseCommand(player.createCommandSourceStack(),
                                               CarpetSettings.carpetCommandPermissionLevel));
    }

    public Map<String, SettingsManager> managers() {
        Map<String, SettingsManager> result = new LinkedHashMap<>();
        Consumer<SettingsManager> add = manager -> {
            for (SettingsManager existing : result.values()) {
                if (existing != manager && existing.identifier().toLowerCase(Locale.ROOT)
                        .equals(manager.identifier().toLowerCase(Locale.ROOT))) {
                    throw new IllegalStateException("规则管理器标识存在文件名冲突：" + manager.identifier());
                }
            }
            SettingsManager previous = result.putIfAbsent(manager.identifier(), manager);
            if (previous != null && previous != manager) {
                throw new IllegalStateException("两个规则管理器使用同一标识：" + manager.identifier());
            }
        };
        CarpetServer.forEachManager(add);
        CarpetGuiApi.additionalManagers().forEach(add);
        return result;
    }

    public List<RuleView> snapshot(MinecraftServer server) {
        List<RuleView> rules = new ArrayList<>();
        for (SettingsManager manager : managers().values()) {
            boolean locked = locked(server, manager);
            for (CarpetRule<?> rule : manager.getCarpetRules()) {
                String description = RuleHelper.translatedDescription(rule);
                for (var extra : rule.extraInfo()) description += "\n" + extra.getString();
                rules.add(new RuleView(manager.identifier(), manager.identifier(), rule.name(), description,
                        List.copyOf(rule.categories()), List.copyOf(rule.suggestions()),
                        rule.type().getSimpleName(), rule.strict(), RuleHelper.toRuleString(rule.value()),
                        RuleHelper.toRuleString(rule.defaultValue()), locked));
            }
        }
        rules.sort(Comparator.comparing(RuleView::manager).thenComparing(RuleView::name));
        return List.copyOf(rules);
    }

    public String set(MinecraftServer server, ServerPlayer player, String managerId, String name, String value) {
        return setWithResult(server, player, managerId, name, value).message();
    }

    public SetResult setWithResult(MinecraftServer server, ServerPlayer player, String managerId, String name, String value) {
        if (!canEdit(server, player)) return new SetResult(false, true,
                "无修改权限：需要存档所有者或具有 Carpet 权限的 OP（等级 2+）。", "");
        SettingsManager manager = managers().get(managerId);
        if (manager == null) return SetResult.rejected("规则管理器不存在，请刷新列表。");
        if (locked(server, manager)) return SetResult.rejected("该规则管理器已锁定，或其配置文件无法安全写入。");
        CarpetRule<?> rule = manager.getCarpetRule(name);
        if (rule == null) return SetResult.rejected("规则不存在，请刷新列表。");
        try {
            WorldConfigStore.validateEntry(managerId, name, value);
        } catch (IOException e) {
            return SetResult.rejected("无法保存此值：" + e.getMessage());
        }
        String before = RuleHelper.toRuleString(rule.value());
        CommandSourceStack source = player.createCommandSourceStack();
        try {
            rule.set(source, value); // Includes all Carpet/extension validators and observers.
            // Persist the validated canonical value (an extension may normalize the input).
            String canonical = RuleHelper.toRuleString(rule.value());
            if (canonical.length() > GuiProtocol.MAX_VALUE_LENGTH) throw new IOException("验证后的值超过 4096 字符。");
            WorldConfigStore.save(worldRoot(server), fallbackRoot(), managerId, name, canonical);
            return new SetResult(true, false, "已应用并保存到当前世界：" + managerId + ":" + name, canonical);
        } catch (InvalidRuleValueException e) {
            e.notifySource(name, source);
            return SetResult.rejected("Carpet 拒绝该值：" + (e.getMessage() == null ? "请查看聊天中的验证说明。" : e.getMessage()));
        } catch (IOException | RuntimeException e) {
            CarpetGui.LOGGER.error("Failed to persist {}:{}", managerId, name, e);
            try {
                rule.set(source, before);
                return SetResult.rejected("应用或写入配置失败，已恢复原规则值：" + e.getMessage());
            } catch (InvalidRuleValueException | RuntimeException rollbackError) {
                CarpetGui.LOGGER.error("Could not restore rule {}:{}", managerId, name, rollbackError);
                return new SetResult(false, true, "写入失败且无法恢复原值。当前值尚未保存，请检查服务器日志！", "");
            }
        }
    }

    private boolean locked(MinecraftServer server, SettingsManager manager) {
        if (manager.locked()) return true;
        try {
            return WorldConfigStore.isLocked(worldRoot(server), fallbackRoot(), manager.identifier());
        } catch (IOException e) {
            CarpetGui.LOGGER.warn("Cannot read settings for {}: {}", manager.identifier(), e.getMessage());
            return true;
        }
    }

    private Path worldRoot(MinecraftServer server) { return server.getWorldPath(LevelResource.ROOT); }
    private Path fallbackRoot() {
        return FabricLoader.getInstance().getEnvironmentType() == EnvType.CLIENT
                ? FabricLoader.getInstance().getConfigDir().resolve("carpet") : null;
    }
}
