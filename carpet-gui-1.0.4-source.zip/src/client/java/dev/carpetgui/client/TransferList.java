package dev.carpetgui.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.ObjectSelectionList;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.List;
import java.util.function.Supplier;

/** A clipped native list for local files, import previews and live per-rule results. */
final class TransferList extends ObjectSelectionList<TransferList.Entry> {
    record Line(String title, String subtitle, Component tooltip, int color, Runnable action) {}
    private final Font font;

    TransferList(Minecraft minecraft, Font font, int x, int y, int width, int height) {
        super(minecraft, width, height, y, 34);
        this.font = font;
        setX(x);
        centerListVertically = false;
    }

    void setLines(List<Supplier<Line>> lines) {
        double scroll = scrollAmount();
        setFocused(null);
        clearEntries();
        lines.forEach(line -> addEntry(new Entry(line)));
        setScrollAmount(scroll);
    }

    @Override public int getRowLeft() { return getX(); }
    @Override public int getRowWidth() { return getWidth() - 12; }
    @Override protected int scrollBarX() { return getRight() - scrollbarWidth(); }
    @Override protected double scrollRate() { return 34; }
    @Override protected void extractListSeparators(GuiGraphicsExtractor graphics) {}
    @Override protected void extractListBackground(GuiGraphicsExtractor graphics) {
        graphics.fill(getX(), getY(), getRight(), getBottom(), 0x442A3844);
    }
    @Override public boolean keyPressed(KeyEvent event) {
        if ((event.key() == GLFW.GLFW_KEY_ENTER || event.key() == GLFW.GLFW_KEY_KP_ENTER || event.key() == GLFW.GLFW_KEY_SPACE)
                && getSelected() != null) {
            getSelected().activate();
            return true;
        }
        return super.keyPressed(event);
    }

    final class Entry extends ObjectSelectionList.Entry<Entry> {
        private final Supplier<Line> contents;
        Entry(Supplier<Line> contents) { this.contents = contents; }
        void activate() { Runnable action = contents.get().action(); if (action != null) action.run(); }
        @Override public Component getNarration() { return contents.get().tooltip(); }
        @Override public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
            if (event.button() != 0) return false;
            setSelected(this);
            activate();
            return true;
        }
        @Override public void extractContent(GuiGraphicsExtractor graphics, int mouseX, int mouseY, boolean hovered, float partialTick) {
            Line line = contents.get();
            graphics.fill(getX() + 1, getY() + 1, getX() + getWidth() - 1, getY() + 31, 0x77314250);
            graphics.text(font, font.plainSubstrByWidth(line.title(), getWidth() - 8), getX() + 4, getY() + 4, line.color());
            graphics.text(font, font.plainSubstrByWidth(line.subtitle(), getWidth() - 8), getX() + 4, getY() + 18, 0xFFBFCAD3);
            if (hovered) graphics.setTooltipForNextFrame(font, line.tooltip(), mouseX, mouseY);
        }
    }
}
