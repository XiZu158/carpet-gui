# 1.0.1 启动崩溃修复

修复日期：2026-10-17。依据用户提供的 `错误报告-2026-10-16_23.02.05.zip`，只把报告内容作为故障诊断数据，没有执行压缩包中的启动脚本。

## 根因

`crash-2026-10-16_23.01.53-client.txt` 第 7–26 行明确指向模组 `carpet_gui` 的公共初始化入口：

```text
Could not execute entrypoint stage 'main' ... 'carpet_gui' ... 'dev.carpetgui.CarpetGui'
Caused by: java.lang.ExceptionInInitializerError
    at dev.carpetgui.network.GuiProtocol.register(...)
Caused by: net.minecraft.IdentifierException:
Non [a-z0-9/._-] character in path of location: minecraft:carpet_gui:request_v1
```

旧代码将完整的 `carpet_gui:request_v1` 传给 `CustomPacketPayload.createType(String)`。Minecraft 26.1.2 中此方法内部使用 `Identifier.withDefaultNamespace`，把参数当作 `minecraft` 命名空间下的路径，而不是解析完整标识，因此产生两个冒号的非法标识。响应通道有同样的问题，现已一起修复。

两个通道现在都用 `new Type<>(Identifier.fromNamespaceAndPath("carpet_gui", "..."))` 显式构造。通道名仍为 `carpet_gui:request_v1` 和 `carpet_gui:response_v1`，协议内容及配置文件格式没有变更。

## 验证证据

- `reproduction-1.0.0.log`：新增 `protocolTest` 对旧代码打包后执行注册，复现报告中的同一 `IdentifierException`，退出码为 1。
- `build-1.0.1.log`：修复版 1.0.1 完整构建成功。78 项存储检查和 16 项网络协议检查通过。网络测试直接加载最终 JAR，使用真实 Minecraft/Fabric 类执行通道注册、两个方向的注册结果检查、Unicode/边界长度数据包往返和超限输入拒绝。
- `server-initialization-1.0.1.log`：Fabric `runServer --args=--initSettings` 成功执行公共入口，出现 `Carpet GUI initialized: request and response channels registered.`。首次创建隔离运行目录时会打印缺少 `server.properties` 和 `eula.txt` 的提示，随后成功生成默认设置并正常退出。这不是模组崩溃。没有接受 EULA、启动世界或修改用户游戏实例。

没有在用户的完整 PCL 整合包中实际进入客户端游戏。游戏内 GUI、存档操作和扩展交互仍需按手动验收清单确认。Windows 无创建测试符号链接权限，相关存储测试仍明确跳过。

## 替换方法

关闭游戏，在 PCL 当前 26.1.2 实例的 `mods` 文件夹中移走本模组 `carpet-gui-1.0.0.jar`，放入 `carpet-gui-1.0.1.jar` 后启动。无需删除存档、`carpet.conf` 或扩展配置，也无需更改本次报告中已有的 Fabric/Carpet 版本。若服务端也安装了本模组，同样替换为 1.0.1。

报告中另有模组 ID `carpetgui`、版本 `1.3.5-hotfix`，它不是本项目的 `carpet_gui`。本次崩溃堆栈直接指向本项目的通道标识问题，不能据此把原因归到那个模组或 PCL 启动器。
