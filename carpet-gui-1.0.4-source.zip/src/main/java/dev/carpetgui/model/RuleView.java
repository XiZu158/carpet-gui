package dev.carpetgui.model;

import java.util.List;

/** Immutable wire view; never exposes Carpet's live rule objects to a client thread. */
public record RuleView(String manager, String managerName, String name, String description,
                       List<String> categories, List<String> options, String type, boolean strict,
                       String value, String defaultValue, boolean locked) {}
