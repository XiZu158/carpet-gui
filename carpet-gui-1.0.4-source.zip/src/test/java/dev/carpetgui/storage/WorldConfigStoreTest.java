package dev.carpetgui.storage;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Comparator;

/** Standalone regression checks; no Minecraft runtime or test library required. */
public final class WorldConfigStoreTest {
    private static int checks;

    public static void main(String[] args) throws Exception {
        Path root = Files.createTempDirectory("carpet-gui-storage-test-");
        try {
            saveAndIsolation(root);
            fallback(root);
            locks(root);
            validation(root);
            preservation(root);
            emptyValue(root);
            failures(root);
            symlinks(root);
            System.out.println("WorldConfigStoreTest: " + checks + " checks passed.");
        } finally {
            try (var paths = Files.walk(root)) {
                for (Path path : paths.sorted(Comparator.reverseOrder()).toList()) Files.deleteIfExists(path);
            }
        }
    }

    private static void saveAndIsolation(Path root) throws Exception {
        Path first = Files.createDirectory(root.resolve("world-one"));
        Path second = Files.createDirectory(root.resolve("world-two"));
        WorldConfigStore.save(first, null, "carpet", "rule", "true");
        WorldConfigStore.save(second, null, "carpet", "rule", "false");
        equal("rule true\n", Files.readString(first.resolve("carpet.conf")), "first world");
        equal("rule false\n", Files.readString(second.resolve("carpet.conf")), "second world");
        WorldConfigStore.save(first, null, "extension.rules", "amount", "3.5");
        equal("amount 3.5\n", Files.readString(first.resolve("extension.rules.conf")), "extension manager");
        equal(false, WorldConfigStore.isLocked(first, null, "carpet"), "unlocked world");
        clean(first);
    }

    private static void fallback(Path root) throws Exception {
        Path world = Files.createDirectory(root.resolve("fallback-world"));
        Path defaults = Files.createDirectory(root.resolve("defaults"));
        String seed = "# Default configuration\r\nunknownExtensionRule keep\r\nrule false\r\n";
        Files.writeString(defaults.resolve("default_carpet.conf"), seed);
        WorldConfigStore.save(world, defaults, "carpet", "rule", "true");
        equal(seed.replace("rule false", "rule true"), Files.readString(world.resolve("carpet.conf")), "fallback seeded");
        equal(seed, Files.readString(defaults.resolve("default_carpet.conf")), "fallback unchanged");
        Files.writeString(defaults.resolve("default_carpet.conf"), "locked\n");
        equal(false, WorldConfigStore.isLocked(world, defaults, "carpet"), "world overrides fallback lock");
        WorldConfigStore.save(world, defaults, "carpet", "rule", "false");
        Path dedicated = Files.createDirectory(root.resolve("dedicated"));
        WorldConfigStore.save(dedicated, null, "carpet", "rule", "true");
        equal("rule true\n", Files.readString(dedicated.resolve("carpet.conf")), "dedicated no fallback");
        Path missing = Files.createDirectory(root.resolve("missing-defaults-world"));
        WorldConfigStore.save(missing, root.resolve("absent-defaults"), "carpet", "rule", "true");
        equal("rule true\n", Files.readString(missing.resolve("carpet.conf")), "absent defaults allowed");
    }

    private static void locks(Path root) throws Exception {
        Path world = Files.createDirectory(root.resolve("locked-world"));
        Path file = world.resolve("carpet.conf");
        for (String marker : new String[]{"locked", "LOCKED", "LoCkEd"}) {
            String original = "# Config\n" + marker + "\nrule false\n";
            Files.writeString(file, original);
            equal(true, WorldConfigStore.isLocked(world, null, "carpet"), "case-insensitive lock");
            fails(() -> WorldConfigStore.save(world, null, "carpet", "rule", "true"));
            equal(original, Files.readString(file), "locked original retained");
        }
        Files.writeString(file, "# locked\n locked\nlocked \n");
        equal(false, WorldConfigStore.isLocked(world, null, "carpet"), "exact independent lock line");
        Path fallbackWorld = Files.createDirectory(root.resolve("locked-fallback-world"));
        Path fallback = Files.createDirectory(root.resolve("locked-fallback"));
        Files.writeString(fallback.resolve("default_carpet.conf"), "locked\n");
        equal(true, WorldConfigStore.isLocked(fallbackWorld, fallback, "carpet"), "fallback lock");
        fails(() -> WorldConfigStore.save(fallbackWorld, fallback, "carpet", "rule", "true"));
        equal(false, Files.exists(fallbackWorld.resolve("carpet.conf")), "fallback lock cannot be bypassed");
    }

    private static void validation(Path root) throws Exception {
        for (String manager : new String[]{"", ".", "..", "../carpet", "..\\carpet", "x/y", "x\\y", "x:y", "x?y",
                "x*y", "x\"y", "x<y", "x>y", "x|y", "x y", "x.", "CON", "con.txt", "COM1", "LPT9"}) {
            fails(() -> WorldConfigStore.validateEntry(manager, "rule", "true"));
        }
        for (String rule : new String[]{"", "a b", "a\tb", "a\nb", "a\rb", "#comment", "a\0b"}) {
            fails(() -> WorldConfigStore.validateEntry("carpet", rule, "true"));
        }
        for (String value : new String[]{"a\nb", "a\rb", " true", "\ttrue", "#comment", "\u00a0true", "a\0b"}) {
            fails(() -> WorldConfigStore.validateEntry("carpet", "rule", value));
        }
        fails(() -> WorldConfigStore.validateEntry(null, "rule", "true"));
        fails(() -> WorldConfigStore.validateEntry("carpet", null, "true"));
        fails(() -> WorldConfigStore.validateEntry("carpet", "rule", null));
        WorldConfigStore.validateEntry("carpet-extra", "rule", "a b # c");
        checks++;
        Path world = Files.createDirectory(root.resolve("validation-world"));
        Path file = world.resolve("carpet.conf");
        Files.writeString(file, "rule original\n");
        fails(() -> WorldConfigStore.save(world, null, "carpet", "rule", "true\nlocked"));
        equal("rule original\n", Files.readString(file), "invalid save preserves original");
        fails(() -> WorldConfigStore.save(world, null, "../escaped", "rule", "true"));
        equal(false, Files.exists(root.resolve("escaped.conf")), "cannot escape world");
        clean(world);
    }

    private static void preservation(Path root) throws Exception {
        Path world = Files.createDirectory(root.resolve("duplicates-world"));
        Path file = world.resolve("carpet.conf");
        Files.writeString(file, "# 中文注释\r\nunknown 42\nrule false\r\n\r\nrule\tduplicate\nmalformed\rrule # ignored\nend keep");
        WorldConfigStore.save(world, null, "carpet", "rule", "true");
        equal("# 中文注释\r\nunknown 42\nrule true\r\n\r\nmalformed\rend keep", Files.readString(file), "duplicates removed; unrelated lines kept");
        WorldConfigStore.save(world, null, "carpet", "another", "value with spaces");
        equal("# 中文注释\r\nunknown 42\nrule true\r\n\r\nmalformed\rend keep\r\nanother value with spaces\r\n",
                Files.readString(file), "append uses existing newline convention");
        clean(world);
    }

    private static void emptyValue(Path root) throws Exception {
        Path world = Files.createDirectory(root.resolve("empty-world"));
        WorldConfigStore.save(world, null, "carpet", "text", "");
        equal("text \n", Files.readString(world.resolve("carpet.conf")), "empty has separator");
        try (var reader = Files.newBufferedReader(world.resolve("carpet.conf"))) {
            String[] fields = reader.readLine().split("\\s+", 2);
            equal(2, fields.length, "Carpet parser sees empty field");
            equal("", fields[1], "empty round-trips");
        }
        Files.writeString(world.resolve("carpet.conf"), "text old");
        WorldConfigStore.save(world, null, "carpet", "text", "");
        equal("text ", Files.readString(world.resolve("carpet.conf")), "missing terminal newline preserved");
    }

    private static void failures(Path root) throws Exception {
        Path world = Files.createDirectory(root.resolve("broken-utf8-world"));
        Path file = world.resolve("carpet.conf");
        byte[] original = {(byte) 0xc3, (byte) 0x28, '\n'};
        Files.write(file, original);
        fails(() -> WorldConfigStore.save(world, null, "carpet", "rule", "true"));
        equal(true, Arrays.equals(original, Files.readAllBytes(file)), "failed UTF-8 read leaves original bytes");
        clean(world);
        Path directoryWorld = Files.createDirectory(root.resolve("directory-target-world"));
        Path directory = Files.createDirectory(directoryWorld.resolve("carpet.conf"));
        Files.writeString(directory.resolve("sentinel"), "preserved");
        fails(() -> WorldConfigStore.save(directoryWorld, null, "carpet", "rule", "true"));
        equal("preserved", Files.readString(directory.resolve("sentinel")), "non-file target preserved");
    }

    private static void symlinks(Path root) throws Exception {
        Path world = Files.createDirectory(root.resolve("symlink-world"));
        Path outside = root.resolve("outside.conf");
        Files.writeString(outside, "rule original\n");
        Path link = world.resolve("carpet.conf");
        try {
            Files.createSymbolicLink(link, outside);
        } catch (UnsupportedOperationException | IOException | SecurityException unavailable) {
            System.out.println("SKIP symlink checks: platform cannot create test symlinks (" + unavailable.getClass().getSimpleName() + ").");
            return;
        }
        fails(() -> WorldConfigStore.save(world, null, "carpet", "rule", "true"));
        fails(() -> WorldConfigStore.isLocked(world, null, "carpet"));
        equal("rule original\n", Files.readString(outside), "symlink target untouched");
        equal(true, Files.isSymbolicLink(link), "symlink retained");
        Path fallbackWorld = Files.createDirectory(root.resolve("symlink-fallback-world"));
        Path fallback = Files.createDirectory(root.resolve("symlink-fallback"));
        Files.createSymbolicLink(fallback.resolve("default_carpet.conf"), outside);
        fails(() -> WorldConfigStore.save(fallbackWorld, fallback, "carpet", "rule", "true"));
        equal(false, Files.exists(fallbackWorld.resolve("carpet.conf")), "symlink fallback refused");
    }

    private static void clean(Path directory) throws IOException {
        try (var files = Files.list(directory)) {
            equal(false, files.anyMatch(path -> path.getFileName().toString().startsWith(".carpet-gui-")), "temp cleanup");
        }
    }

    private static void equal(Object expected, Object actual, String description) {
        if (!expected.equals(actual)) throw new AssertionError(description + ": expected <" + expected + ">, got <" + actual + ">");
        checks++;
    }

    private static void fails(ThrowingRunnable action) throws Exception {
        try {
            action.run();
        } catch (IOException expected) {
            checks++;
            return;
        }
        throw new AssertionError("Expected IOException");
    }

    @FunctionalInterface
    private interface ThrowingRunnable { void run() throws Exception; }
}
