package dev.carpetgui.network;

import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/** Versioned, bounded messages. Rule identifiers and values are data, never executable commands. */
public final class GuiProtocol {
    public static final int MAX_VALUE_LENGTH = 4096;
    public static final int MAX_JSON_LENGTH = 1_000_000;
    public static final String IMPORT_ACTION = "import_set";
    public static final int TRANSFER_VERSION = 1;

    /** A save acknowledgement, not a snapshot. Success means the native world file was written. */
    public record ImportReply(String operation, boolean success, boolean stop, String manager,
                              String rule, String value, String message) {}

    public record Request(int requestId, String action, String manager, String rule, String value)
            implements CustomPacketPayload {
        // createType(String) assumes the minecraft namespace; mod channels need an explicit identifier.
        public static final Type<Request> TYPE = new Type<>(Identifier.fromNamespaceAndPath("carpet_gui", "request_v1"));
        public static final StreamCodec<RegistryFriendlyByteBuf, Request> CODEC = StreamCodec.of(
                (buf, packet) -> {
                    buf.writeVarInt(packet.requestId());
                    buf.writeUtf(packet.action(), 16);
                    buf.writeUtf(packet.manager(), 256);
                    buf.writeUtf(packet.rule(), 256);
                    buf.writeUtf(packet.value(), MAX_VALUE_LENGTH);
                }, buf -> new Request(buf.readVarInt(), buf.readUtf(16), buf.readUtf(256),
                        buf.readUtf(256), buf.readUtf(MAX_VALUE_LENGTH)));
        @Override public Type<Request> type() { return TYPE; }
    }

    public record Response(int requestId, String json) implements CustomPacketPayload {
        public static final Type<Response> TYPE = new Type<>(Identifier.fromNamespaceAndPath("carpet_gui", "response_v1"));
        public static final StreamCodec<RegistryFriendlyByteBuf, Response> CODEC = StreamCodec.of(
                (buf, packet) -> {
                    buf.writeVarInt(packet.requestId());
                    buf.writeUtf(packet.json(), MAX_JSON_LENGTH);
                }, buf -> new Response(buf.readVarInt(), buf.readUtf(MAX_JSON_LENGTH)));
        @Override public Type<Response> type() { return TYPE; }
    }

    public static void register() {
        PayloadTypeRegistry.serverboundPlay().register(Request.TYPE, Request.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(Response.TYPE, Response.CODEC);
    }
    private GuiProtocol() {}
}
