package dev.carpetgui;

import com.google.gson.Gson;
import dev.carpetgui.model.RuleView;
import dev.carpetgui.network.GuiProtocol;
import dev.carpetgui.server.RuleService;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public final class CarpetGui implements ModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("carpet_gui");
    private static final Gson GSON = new Gson();
    private final RuleService rules = new RuleService();
    private final Map<UUID, Long> lastRequest = new HashMap<>();

    public record SnapshotPage(String world, boolean canEdit, String message, boolean error,
                               int page, int pages, List<RuleView> rules, int transferVersion) {}

    @Override public void onInitialize() {
        GuiProtocol.register();
        ServerPlayNetworking.registerGlobalReceiver(GuiProtocol.Request.TYPE, (request, context) ->
                context.server().execute(() -> handle(context.server(), context.player(), request)));
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> lastRequest.remove(handler.player.getUUID()));
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> lastRequest.clear());
        LOGGER.info("Carpet GUI initialized: request and response channels registered.");
    }

    private void handle(MinecraftServer server, ServerPlayer player, GuiProtocol.Request request) {
        if (player.hasDisconnected() || !ServerPlayNetworking.canSend(player, GuiProtocol.Response.TYPE)) return;
        String world = server.getWorldData().getLevelName();
        boolean allowed = rules.canEdit(server, player);
        if (!allowed) {
            reject(player, request, world, false,
                    "需要存档所有者或具有 Carpet 命令权限的 OP（等级 2+）才能读取和修改规则。");
            return;
        }
        long now = System.nanoTime();
        Long previous = lastRequest.put(player.getUUID(), now);
        if (previous != null && now - previous < 150_000_000L) {
            reject(player, request, world, true, "请求过于频繁，请稍后刷新。");
            return;
        }
        try {
            if (request.action().equals(GuiProtocol.IMPORT_ACTION)) {
                RuleService.SetResult result = rules.setWithResult(server, player, request.manager(), request.rule(), request.value());
                importReply(player, request, result);
                return;
            }
            if (!request.action().equals("snapshot") && !request.action().equals("set")) {
                failure(player, request.requestId(), world, allowed, "未知请求，请更新客户端和服务端的 Carpet GUI。");
                return;
            }
            String message = switch (request.action()) {
                case "snapshot" -> "已读取当前世界的全部规则。";
                case "set" -> rules.set(server, player, request.manager(), request.rule(), request.value());
                default -> "未知请求，请更新客户端和服务端的 Carpet GUI。";
            };
            send(player, request.requestId(), world, rules.canEdit(server, player), message, rules.snapshot(server));
        } catch (RuntimeException e) {
            LOGGER.error("Carpet GUI request failed", e);
            reject(player, request, world, false, "处理规则失败：" + e.getMessage());
        }
    }

    private void send(ServerPlayer player, int requestId, String world, boolean allowed,
                      String message, List<RuleView> snapshot) {
        int pages = Math.max(1, (snapshot.size() + 15) / 16);
        // Serialize all pages before sending so a failed extension cannot leave a half snapshot.
        var packets = new java.util.ArrayList<GuiProtocol.Response>(pages);
        for (int page = 0; page < pages; page++) {
            List<RuleView> slice = snapshot.subList(page * 16, Math.min(snapshot.size(), (page + 1) * 16));
            String json = GSON.toJson(new SnapshotPage(world, allowed, message, false, page, pages, slice, GuiProtocol.TRANSFER_VERSION));
            if (json.length() > GuiProtocol.MAX_JSON_LENGTH || json.getBytes(StandardCharsets.UTF_8).length > 900_000)
                throw new IllegalArgumentException("扩展规则描述过大，无法发送。请联系该扩展作者。");
            packets.add(new GuiProtocol.Response(requestId, json));
        }
        packets.forEach(packet -> ServerPlayNetworking.send(player, packet));
    }

    private void failure(ServerPlayer player, int requestId, String world, boolean allowed, String message) {
        String json = GSON.toJson(new SnapshotPage(world, allowed, message, true, 0, 1, List.of(), GuiProtocol.TRANSFER_VERSION));
        ServerPlayNetworking.send(player, new GuiProtocol.Response(requestId, json));
    }

    private void reject(ServerPlayer player, GuiProtocol.Request request, String world, boolean allowed, String message) {
        if (request.action().equals(GuiProtocol.IMPORT_ACTION))
            importReply(player, request, new RuleService.SetResult(false, true, message, ""));
        else failure(player, request.requestId(), world, allowed, message);
    }

    private void importReply(ServerPlayer player, GuiProtocol.Request request, RuleService.SetResult result) {
        String message = result.message();
        if (message.length() > 2048) message = message.substring(0, 2048);
        String json = GSON.toJson(new GuiProtocol.ImportReply(GuiProtocol.IMPORT_ACTION, result.success(), result.stop(),
                request.manager(), request.rule(), result.value(), message));
        ServerPlayNetworking.send(player, new GuiProtocol.Response(request.requestId(), json));
    }
}
