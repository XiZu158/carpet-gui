package dev.carpetgui.transfer;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** One request at a time; a timeout never replays a possibly completed write. */
public final class ImportRun {
    public enum State { PENDING, SENDING, SAVED, FAILED, UNKNOWN, CANCELLED }
    public record Result(State state, String value, String message) {}
    private final List<RuleConfigFile.Entry> entries;
    private final Map<String, Result> results = new LinkedHashMap<>();
    private int cursor;
    private RuleConfigFile.Entry current;
    private boolean stopped;
    private long revision;

    public ImportRun(List<RuleConfigFile.Entry> entries) {
        this.entries = List.copyOf(entries);
        for (var entry : entries) {
            if (results.putIfAbsent(entry.id(), new Result(State.PENDING, entry.value(), "")) != null)
                throw new IllegalArgumentException("Duplicate import rule: " + entry.id());
        }
    }

    public RuleConfigFile.Entry next() {
        if (current != null) throw new IllegalStateException("An import request is still in flight");
        if (stopped || cursor == entries.size()) return null;
        current = entries.get(cursor++);
        results.put(current.id(), new Result(State.SENDING, current.value(), ""));
        revision++;
        return current;
    }

    public void acknowledge(String manager, String rule, boolean success, String value, String message, boolean stop) {
        if (current == null || !current.manager().equals(manager) || !current.rule().equals(rule))
            throw new IllegalArgumentException("Import acknowledgement does not match its request");
        results.put(current.id(), new Result(success ? State.SAVED : State.FAILED, value, message));
        current = null;
        revision++;
        if (stop) stop(message, false);
    }

    public void unknown(String message) {
        if (current != null) {
            results.put(current.id(), new Result(State.UNKNOWN, current.value(), message));
            current = null;
        }
        stop(message, false);
    }

    /** An unsent queued request can be cancelled; a sent request must await its acknowledgement. */
    public void stop(String message, boolean cancelUnsent) {
        stopped = true;
        if (cancelUnsent && current != null) {
            results.put(current.id(), new Result(State.CANCELLED, current.value(), message));
            current = null;
        }
        while (cursor < entries.size()) {
            var entry = entries.get(cursor++);
            results.put(entry.id(), new Result(State.CANCELLED, entry.value(), message));
        }
        revision++;
    }

    public boolean active() { return current != null || (!stopped && cursor < entries.size()); }
    public RuleConfigFile.Entry current() { return current; }
    public Result result(String id) { return results.get(id); }
    public long count(State state) { return results.values().stream().filter(result -> result.state() == state).count(); }
    public int size() { return entries.size(); }
    public long revision() { return revision; }
}
