# Carpet GUI

Minecraft Java **26.1.2** 的 Fabric 模组，为 Carpet 本体及扩展的已注册规则提供图形化配置。项目目录名为 **carpet GUI**，模组 ID 为 `carpet_gui`。

**当前版本 1.0.4**：新增“导出已开启”和跨存档配置导入，支持预览、逐条应用并保存、查看成功/失败结果；保留中文名称、状态栏目、滚轮浏览及启动崩溃修复。使用 PCL 时，打开该游戏版本的 `mods` 文件夹，移走本模组旧版 JAR，再放入 `carpet-gui-1.0.4.jar`。不要同时安装本模组两个版本。存档和现有 Carpet 配置无需删除。详见 [1.0.4 更新说明](verification/features-1.0.4.md)、[1.0.3 更新说明](verification/features-1.0.3.md)、[1.0.2 更新说明](verification/features-1.0.2.md) 和 [1.0.1 修复说明](verification/fix-1.0.1.md)。

## 依赖和安装

| 组件 | 本次编译和测试使用的版本 | 运行要求 |
| --- | --- | --- |
| Minecraft Java | 26.1.2 | 仅 26.1.2 |
| Java | JDK 25 | Java 25 或以上；开发建议 JDK 25 |
| Fabric Loader | 0.19.3 | 0.19.3 或以上 |
| Fabric API | 0.151.0+26.1.2 | 该版本或支持 26.1.2 的更新版本 |
| Carpet | 26.1+v260402 | 支持 26.1.2 的 Carpet 26.1 系列 |
| Fabric Loom | 1.16.3 | 构建依赖，已锁定 |
| Gradle | 9.4.1 | 已包含 Wrapper 及发行包 SHA-256 校验 |

将 `dist/carpet-gui-1.0.4.jar` 与 Fabric API、Carpet 一起放入游戏实例的 `mods` 目录。不要安装 `-sources.jar`。单人游戏只需在客户端安装；多人游戏需要**客户端和服务端均安装本模组，导入要求双方为 1.0.4 或以上版本**。服务端不加载 GUI 类。第三方 Carpet 扩展照常安装。

Carpet 官方发布的 [26.1 / v260402](https://modrinth.com/mod/carpet/version/ygtmLbO3) 标注支持 26.1、26.1.1 和 26.1.2。构建通过 Modrinth Maven 的不可变版本 ID `ygtmLbO3` 固定此发布包，没有把 Carpet 或 Minecraft 打包进本模组。依赖声明允许兼容更新，但本次没有逐个测试所有更高版本。

## 使用

1. 进入世界，按 **G** 打开，或输入客户端命令 `/carpetgui`。快捷键可在游戏“控制”设置中修改。
2. 点击顶部“全部 / 已开启 / 已修改”切换栏目，再使用“来源”和“分类”缩小范围。搜索同时匹配中文名称、原始规则 ID、说明、来源及分类；所有筛选可以叠加。**将鼠标移到规则列表内，使用滚轮上下浏览**，也可拖动右侧滚动条；顶部筛选和底部操作按钮保持固定。
3. 点击规则当前值进入详情，返回时保留滚动位置。切换栏目、来源、分类或搜索条件时回到顶部；刷新或改变窗口大小时保留位置，并限制在有效范围内。布尔规则使用开关选择；严格枚举使用选项切换；数值、字符串及其他非严格规则使用输入框，并显示类型和建议值。
4. “默认值”只填入草稿。点击“应用并保存”后，服务端验证、应用并写入该世界的配置文件，界面收到服务端确认后才更新当前值。当前值与默认值不同时使用不同文字颜色。
5. “刷新”获取命令或其他管理员修改后的状态。界面不会持续轮询其他操作者的修改；多名管理员编辑同一规则时，最后成功应用的值生效。
6. 点击底部“导入 / 导出”进入跨存档配置界面。“导出全部”重新读取**完整服务端快照**，包括默认值规则、所有分类及所有已发现扩展；“导出已开启”从新快照中选择已启用的功能。两种导出均不受主列表筛选和滚动位置影响。完成后在界面及聊天显示本机文件路径。

普通玩家不能读取或更改配置。允许单人世界的存档所有者操作（无需开启作弊）；远程玩家须具有 OP 等级 2 对应权限，并通过 Carpet 的 `carpetCommandPermissionLevel` 检查。每次请求均由服务端重新检查权限。本地存档所有者不受该命令权限规则限制，但仍然遵守管理器的 `locked` 锁定状态。锁定管理器可查看与导出，不能修改。

界面文字提供简体中文和英文。**将 Minecraft 游戏语言设为“简体中文”后，列表和详情标题会显示中文规则名称**，同时保留 `carpet:原始规则ID` 以便查找和对照命令。无需修改 Carpet 的 `language` 规则；不会改变服务端或其他玩家的语言。规则说明仍完整保留 Carpet 当前配置语言及扩展提供的动态信息，服务端状态消息当前使用中文。

本模组复用 Carpet 自带中文资源，并补齐 26 个遗漏名称。针对目标 Carpet 26.1+v260402 的全部 83 个注解规则，已验证中文名称覆盖。扩展优先使用客户端资源包中的译名，其次尝试已安装扩展的 `canHasTranslations`；没有译文时显示原始 ID。只有服务端安装、客户端没有对应译文的扩展，不能凭空获得中文名称。

“已开启”包含值为 `true` 的布尔规则，以及值为 `true`、`ops` 或 `0`–`4` 的字符串命令权限规则（须带 `command` 分类和 `false` 选项）；内置默认开启的规则也在其中。数值、文本和普通枚举没有通用的启用含义，不猜测它们是否开启，可在“已修改”栏查看当前值不同于内置默认值的项目。被关闭的默认开启规则会出现在“已修改”，不会出现在“已开启”。栏目数量随搜索、来源、分类变化；“导出全部”始终包含完整快照，“导出已开启”采用上述启用判定。

## 把已开启功能迁移到另一存档

1. 在来源存档 A 按 **G → 导入 / 导出 → 导出已开启**，等待生成 TXT 文件。
2. 进入目标存档 B，按 **G → 导入 / 导出**。同一游戏实例会直接列出 A 的导出文件，点击文件即可预览。另一个 PCL 实例的文件可通过“打开文件夹”复制进目标实例的 `config/carpet-gui/exports/` 后刷新列表，也可将单个 TXT 文件拖入此界面。
3. 默认模式为**仅开启**：按文件中的值启用布尔规则与命令权限规则。文件没有列出的目标规则保持原值；文件中的 false、数值和普通文本不在此模式下应用。
4. 预览列出将保存的条目，以及缺失扩展、锁定或不适用的条目。悬停可查看完整名称、当前值 → 文件值和跳过原因。
5. 点击**应用并保存**，等待各项显示“已保存”。每项都经过 Carpet 验证并写入 B 的原生 `.conf`，重启后由 Carpet 加载；保存完成后自动刷新目标存档快照。

如需迁移数值、字符串、枚举或关闭状态，在 A 使用“导出全部”，在 B 的预览中将模式切换为**按文件值**。该模式应用文件列出的所有可用条目的值，可能关闭功能；仍不改动文件中没有列出的规则。兼容 1.0.3 及同格式的旧版导出文件。

导入是逐条保存，成功项目不会因另一项失败而整体撤销。普通无效值会单独报告失败并继续其他项目；权限撤销、通信异常或无法恢复的写入异常会停止后续导入。点击“停止后续导入”或返回列表会停止未发送的项目；已发送的一项仍可能保存。超时项标为“待确认”，不会自动重发，需刷新检查实际值。导入命令权限规则后，远程操作者可能失去后续操作权限；单人世界仍按存档所有者权限判断。

按 `管理器:规则名` 精确匹配，缺少的扩展不会自动安装，规则改名也不会猜测映射。当前值与文件值相同的项目仍会保存，便于把临时命令修改持久化。导入文件中的世界名仅用于提示，目标始终是当前连接的世界。

## 每个世界独立保存

本模组直接维护 Carpet 原生文件，不另建全局规则数据库：

```text
游戏实例/
├─ saves/世界A/
│  ├─ carpet.conf
│  └─ 扩展管理器标识.conf
├─ saves/世界B/
│  ├─ carpet.conf
│  └─ 扩展管理器标识.conf
└─ config/carpet-gui/exports/
   └─ carpet-世界A-日期时间-随机标识.txt
```

专用服务器的配置在其实际世界根目录（通常 `world/`），不是客户端的 `saves/`。维度共享所属世界的规则配置。

保存流程为 `CarpetRule.set` 验证和应用 → 读取现有配置 → 更新当前规则 → 同目录临时文件写入 → 替换目标文件。其他规则、未知项、注释和换行会保留；同名规则的重复项会合并。文件系统支持时使用原子替换，不支持时退回同目录替换。首次保存时，客户端环境会继承 `config/carpet/default_<管理器>.conf` 的内容，避免创建世界配置后丢失默认覆盖项；专用服务器不使用客户端 fallback。

世界重新加载时，Carpet 自己的 `SettingsManager.attachServer` 读取这些文件；退出世界时，`detachServer` 重置规则。GUI 连接状态在断开时清空，避免把上一存档的快照带入下一存档。

通过 GUI 单项保存或导入成功的规则会写盘；原版 `/carpet <rule> <value>` 的临时修改仍遵循 Carpet 自身行为。需要把这种当前值持久化时，可进入 GUI 直接点击“应用并保存”。导出包含所选范围规则的**当前运行值**，其中也可能包含尚未持久化的命令修改。

写入失败会报告错误并尝试通过 Carpet API 恢复原规则值，不会声称保存成功。第三方验证器/观察器触发的其他游戏副作用不一定能被撤销。运行中不要同时手动编辑配置文件；有并发内容变化检测，但不提供跨进程事务锁。

## 扩展规则发现和注册 API

每次读取都调用 `CarpetServer.forEachManager`，自动包含：

- Carpet 主 `SettingsManager` 中的所有 `getCarpetRules()`。
- `CarpetExtension.extensionSettingsManager()` 返回的各扩展管理器中的全部规则。
- 运行时动态添加到这些管理器的规则（刷新即可显示）。

使用 `(manager.identifier(), rule.name())` 作为规则身份，不会因两个扩展有同名规则而混淆。管理器的公开 API 没有显示名称 getter，所以界面来源采用其真实标识。不同对象的管理器标识若相同或仅大小写不同，会拒绝生成快照并提示冲突，防止在 Windows 下写入同一文件。

正常 Carpet 扩展无需适配。对于没有被 `forEachManager` 枚举的自定义管理器，提供公开入口：

```java
import dev.carpetgui.api.CarpetGuiApi;

// 在扩展初始化时注册一次；supplier 在服务端线程、每次请求时求值。
CarpetGuiApi.registerManager(() -> mySettingsManager);
```

扩展仍需负责管理器的服务端 attach/detach 和原生 `.conf` 加载，且值必须能用 `RuleHelper.toRuleString` 表达。尚未准备好的 supplier 可以返回 `null`。如把 Carpet GUI 设为可选依赖，先检查 `FabricLoader.getInstance().isModLoaded("carpet_gui")`，再通过独立兼容类调用此 API，避免未安装时类加载失败。

这些约束对应 Carpet 的规则 API。未注册为 CarpetRule 的独立模组设置、`/tick`、`/player`、`/log` 操作以及 Scarpet 脚本本身，不会自动变成 GUI 规则；需要扩展作者提供规则或桥接。

## 文本导出

文件为 UTF-8，按管理器和规则名排序，包含世界名、导出时间、规则总数、每一项的完整标识及当前值。例如：

```text
# Carpet GUI — complete server snapshot
# World: 示例世界
# Exported: ...
# Rules: ...

[carpet] # carpet
carpet:某个规则名 = true

[extension] # extension
extension:某个数值规则 = 5
```

反斜线、换行、回车和制表符使用转义形式。导出采用时间戳和随机标识，不覆盖已有文件；已开启规则文件以 `carpet-enabled-` 开头。此格式支持 GUI 预览导入，不能原样复制为 `carpet.conf`。文件中的注释和分组不会作为命令执行。

导入读取 UTF-8（允许 BOM、LF/CRLF），单文件最多 4 MiB、4096 条规则，每个值最多 4096 字符。格式错误、未知转义、重复规则及非法 UTF-8 会在应用前拒绝整个文件；完整解析成功后，再在预览中标出无法保存的值、缺失或锁定规则。文件列表显示文件夹内最近修改的 512 个 TXT 文件，其他文件可直接拖入。暂不支持原生 `.conf`、CSV 或 JSON 文件导入。

## 构建

安装 JDK 25，设置 `JAVA_HOME` 指向 JDK 目录。Windows PowerShell：

```powershell
cd 'carpet GUI'
.\gradlew.bat build
```

Linux/macOS：

```sh
cd 'carpet GUI'
bash gradlew build
```

首次构建需要访问 Gradle、Fabric、Mojang、Maven Central 和 Modrinth。无需 Yarn 映射：26.1.2 使用未混淆命名与 `net.fabricmc.fabric-loom` 插件。参见 [Fabric 26.1 升级说明](https://fabricmc.net/2026/03/14/261.html) 和 [Fabric 26.1 示例项目](https://github.com/FabricMC/fabric-example-mod/tree/26.1)。

构建输出：`build/libs/carpet-gui-1.0.4.jar` 与源码 JAR。交付目录 `dist/` 是本次已验证构建的副本；后续重建以 `build/libs/` 为准。

`build` 会运行 `storageTest`、`protocolTest`、`activityTest`、`localizationTest` 和 `transferTest` 五个独立 Java 回归程序；未引入 JUnit，标准 `test` 任务显式禁用，实际检查由 `check` 依赖的五个任务执行。协议测试从构建的 JAR 加载协议类，使用真实 Minecraft/Fabric 依赖执行注册、数据包往返、导入确认和长度边界检查；语言测试读取最终 JAR 的语言资源，逐个检查目标 Carpet 规则的中文名称覆盖；导入测试覆盖解析、筛选、确认队列及两份独立世界配置文件的迁移。可单独运行 `gradlew.bat transferTest`。开发启动可用 `gradlew.bat runClient` 或 `gradlew.bat runServer`，开发世界与正式游戏存档独立。

## 项目结构

```text
carpet GUI/
├─ build.gradle / settings.gradle / gradle.properties
├─ gradlew / gradlew.bat / gradle/wrapper/
├─ src/main/resources/
│  ├─ fabric.mod.json
│  └─ assets/carpet_gui/lang/{zh_cn,en_us}.json
├─ src/main/java/dev/carpetgui/
│  ├─ CarpetGui.java                 # 服务端入口、权限门槛、请求处理
│  ├─ api/CarpetGuiApi.java           # 非标准扩展注册入口
│  ├─ model/RuleView.java             # 不可变规则快照
│  ├─ model/RuleActivity.java         # 已开启/已修改状态判定
│  ├─ model/RuleLabels.java           # 名称/分类翻译和 ID 回退
│  ├─ network/GuiProtocol.java        # 双向有界数据包
│  ├─ server/RuleService.java         # 发现、验证、应用、持久化协调
│  ├─ transfer/RuleConfigFile.java    # 新旧导出文本解析与生成
│  ├─ transfer/ImportPlan.java        # 目标存档匹配、导入模式和预览
│  ├─ transfer/ImportRun.java         # 逐条确认、失败结果和停止逻辑
│  └─ storage/WorldConfigStore.java   # 世界原生配置文件存储
├─ src/client/java/dev/carpetgui/client/
│  ├─ CarpetGuiClient.java           # G 键与客户端命令
│  ├─ ClientState.java               # 快照聚合、导入确认、导出与断开清理
│  ├─ RuleText.java                  # 客户端语言及扩展译名
│  ├─ RulesScreen.java               # 搜索/分类/来源/原生滚动列表
│  ├─ TransferScreen.java            # 文件选择、导入预览、结果与导出
│  ├─ TransferList.java              # 文件和导入条目的原生滚动列表
│  └─ RuleEditScreen.java            # 规则详情与控件
├─ src/test/java/dev/carpetgui/
│  ├─ storage/WorldConfigStoreTest.java
│  ├─ network/GuiProtocolTest.java
│  ├─ transfer/RuleTransferTest.java
│  └─ model/{RuleActivityTest,RuleLabelsTest}.java
├─ dist/                             # 已构建模组及源码 JAR
├─ verification/                     # 本次构建记录与手动验收清单
├─ README.md
└─ LICENSE
```

## 已验证和待确认

已实现：动态规则及扩展发现、中文规则名称、已开启/已修改栏目、分类/来源/中英文搜索、滚轮和滚动条浏览、布尔/枚举/数值/文本编辑、服务端权限与锁检查、Carpet 验证器、原生世界持久化、完整/已开启文本导出、跨存档导入预览和逐项结果、自定义管理器注册 API、超时和断开清理。

1.0.4 完整构建通过，共 492 项检查（存储 78、协议 24、状态 64、语言 252、导入迁移 74），记录见 `verification/build.log`。导入测试使用临时世界目录，确认只写目标配置、保留未列出规则、源文件不变、锁定写入被拒绝；未启动真实世界，也未执行游戏内拖放/点击/导入后重启的端到端验收。中文名称覆盖仍为目标 Carpet 的 83/83 条规则。详见 `verification/features-1.0.4.md`。

1.0.3 完整构建通过，现有 330 项检查全部通过（存储 78、协议 16、状态 64、语言 172）。使用 Minecraft 原生列表控件处理连续滚动、边界限制、裁剪和滚动条拖动；按钮位置随滚动同步更新。历史构建记录见 `verification/build-1.0.3.log`；实际游戏内滚动交互尚待验收，项目见 `verification/features-1.0.3.md`。界面取消分页，网络传输仍使用原有分包聚合。

1.0.2 完整构建通过：78 项存储检查、16 项协议检查、64 项启用/修改状态检查、172 项语言检查，共 330 项检查，历史记录见 `verification/build-1.0.2.log`。语言测试确认目标 Carpet 的 83/83 个注解规则都有中文名称。尚未进行游戏内视觉与交互验收。

1.0.1 完成 Java 25 下客户端/公共端编译、JAR 打包、78 项存储检查和 16 项真实协议注册/编解码检查。新增协议测试在修复前准确复现用户报告的 `ExceptionInInitializerError`，修复后通过。

另外执行 Fabric 专用服务器 `--initSettings` 检查：日志确认加载 Minecraft 26.1.2、Loader 0.19.3、Fabric API 0.151.0+26.1.2、Carpet 26.1+v260402 和 Carpet GUI 1.0.1，且打印 `Carpet GUI initialized: request and response channels registered.`，证明模组公共入口实际执行成功。此前 1.0.0 的 `--help` 检查提前返回，没有执行该入口，不能验证此类初始化问题。新的检查也没有创建世界，**不等同于用户完整 PCL 整合包、客户端 GUI 或联机功能的验收**。

仍待人工确认：游戏内 GUI 实际显示与交互、真实存档切换/重启的端到端流程、远程多人权限交互，以及具体第三方 Carpet 扩展的验证器副作用。Windows 环境不能创建测试符号链接，相关执行测试已跳过；不支持原子移动的文件系统回退分支未强制模拟。详见 `verification/manual-checklist.md`。

其他边界：GUI 单次输入上限 4096 字符；管理器和规则标识传输上限 256 字符；拒绝原生 conf 无法可靠表示的换行或以空白/`#` 开头的值。管理器文件名仅允许 ASCII 字母数字、点、下划线和连字符，并排除路径穿越和 Windows 设备名。极大扩展快照受到分包与消息大小上限保护，超限会报告错误。没有 Mod Menu 入口、整次导入的事务回滚、自动安装扩展或持续实时订阅功能。

API 参考：[Carpet 26.1 源码](https://github.com/gnembon/fabric-carpet/tree/26.1)、[SettingsManager](https://github.com/gnembon/fabric-carpet/blob/26.1/src/main/java/carpet/api/settings/SettingsManager.java)、[CarpetRule](https://github.com/gnembon/fabric-carpet/blob/26.1/src/main/java/carpet/api/settings/CarpetRule.java)。
