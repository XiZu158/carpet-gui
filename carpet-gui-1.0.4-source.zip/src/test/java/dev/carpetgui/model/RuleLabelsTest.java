package dev.carpetgui.model;

import carpet.CarpetSettings;
import carpet.settings.Rule;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Verifies actual packaged language resources against the targeted Carpet rule definitions. */
public final class RuleLabelsTest {
    private static int checks;

    public static void main(String[] args) throws Exception {
        Map<String, String> baseChinese = read("/assets/carpet/lang/zh_cn.json");
        Map<String, String> ownChinese = read("/assets/carpet_gui/lang/zh_cn.json");
        Map<String, String> ownEnglish = read("/assets/carpet_gui/lang/en_us.json");
        Map<String, String> chinese = new HashMap<>(baseChinese);
        chinese.putAll(ownChinese);
        int ruleCount = 0;
        for (var field : CarpetSettings.class.getDeclaredFields()) {
            if (!field.isAnnotationPresent(Rule.class)) continue;
            ruleCount++;
            String name = RuleLabels.name(rule("carpet", field.getName()), chinese::get);
            require(name.codePoints().anyMatch(code -> Character.UnicodeScript.of(code) == Character.UnicodeScript.HAN),
                    "Missing Chinese name for " + field.getName());
        }
        require(ruleCount > 0, "No Carpet rules inspected");
        equal("爆炸掉落经验", RuleLabels.name(rule("carpet", "xpFromExplosions"), chinese::get), "supplemented name");
        equal("可移动紫水晶母岩", RuleLabels.name(rule("carpet", "movableAmethyst"), chinese::get), "supplemented name");
        equal("missingRule", RuleLabels.name(rule("addon", "missingRule"), chinese::get), "unknown extension fallback");
        Map<String, String> extensions = Map.of("addon.rule.xpFromExplosions.name", "插件经验", "addon.category.test", "测试 100%");
        equal("插件经验", RuleLabels.name(rule("addon", "xpFromExplosions"), extensions::get), "manager-specific name");
        equal("xpFromExplosions", RuleLabels.name(rule("carpet", "xpFromExplosions"), extensions::get), "no manager collision");
        equal("测试 100%", RuleLabels.category("addon", "test", extensions::get), "percent not interpreted as a format");
        equal("technical", RuleLabels.category("addon", "technical", key -> null), "category ID fallback");
        equal("missingRule", RuleLabels.name(rule("addon", "missingRule"), key -> key), "missing translation key fallback");
        equal("missingRule", RuleLabels.name(rule("addon", "missingRule"), key -> " "), "blank label fallback");
        RuleView stable = rule("carpet", "xpFromExplosions");
        RuleLabels.name(stable, chinese::get);
        equal("xpFromExplosions", stable.name(), "display name does not change configuration identity");
        for (String key : ownEnglish.keySet()) require(ownChinese.containsKey(key), "Missing Chinese UI key " + key);
        for (String key : ownChinese.keySet()) {
            if (key.startsWith("carpet_gui.") || key.startsWith("key.")) require(ownEnglish.containsKey(key), "Missing English UI key " + key);
        }
        System.out.println("RuleLabelsTest: " + checks + " checks passed; " + ruleCount + "/" + ruleCount
                + " Carpet rule names have Chinese translations in the packaged resources.");
    }

    private static RuleView rule(String manager, String name) {
        return new RuleView(manager, manager, name, "Server description", List.of("test"), List.of("true", "false"),
                "Boolean", true, "true", "false", false);
    }

    private static Map<String, String> read(String path) throws Exception {
        var input = RuleLabelsTest.class.getResourceAsStream(path);
        if (input == null) throw new AssertionError("Missing resource " + path);
        try (var reader = new InputStreamReader(input, StandardCharsets.UTF_8)) {
            return new Gson().fromJson(reader, new TypeToken<Map<String, String>>() {}.getType());
        }
    }

    private static void require(boolean value, String label) {
        if (!value) throw new AssertionError(label);
        checks++;
    }

    private static void equal(Object expected, Object actual, String label) {
        require(expected.equals(actual), label + ": expected " + expected + ", got " + actual);
    }
}
