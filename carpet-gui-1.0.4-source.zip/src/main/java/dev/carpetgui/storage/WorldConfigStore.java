package dev.carpetgui.storage;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Writes Carpet's native world/{manager}.conf format. The fallback root directly
 * contains default_{manager}.conf (normally config/carpet), or is null on servers.
 * World roots must exist. Trusted roots are resolved to real paths; config-file
 * symlinks are refused. Saves are serialized in this JVM, not across processes.
 */
public final class WorldConfigStore {
    private WorldConfigStore() {}

    /** Reject names and values that cannot round-trip through Carpet's parser. */
    public static void validateEntry(String manager, String rule, String value) throws IOException {
        validateManager(manager);
        if (rule == null || rule.isEmpty() || rule.startsWith("#")
                || rule.codePoints().anyMatch(c -> whitespace(c) || Character.isISOControl(c))) {
            throw new IOException("Rule names must be nonempty and contain no whitespace or control characters.");
        }
        if (value == null || value.indexOf('\r') >= 0 || value.indexOf('\n') >= 0 || value.indexOf('\0') >= 0) {
            throw new IOException("Rule values must not contain line breaks or NUL characters.");
        }
        if (!value.isEmpty() && (whitespace(value.codePointAt(0)) || value.startsWith("#"))) {
            throw new IOException("Carpet cannot persist values beginning with whitespace or '#'.");
        }
    }

    /** Change one rule while retaining unrelated entries, comments and line endings. */
    public static synchronized void save(Path worldRoot, Path fallbackConfigRoot,
                                         String manager, String rule, String value) throws IOException {
        validateEntry(manager, rule, value);
        Path target = target(worldRoot, manager);
        Source before = readSource(target, fallbackConfigRoot, manager);
        if (locked(before.content())) throw new IOException("Carpet settings are locked for '" + manager + "'.");
        String updated = update(before.content(), rule, value);
        Path temporary = Files.createTempFile(target.getParent(), ".carpet-gui-", ".tmp");
        try {
            try (FileChannel output = FileChannel.open(temporary, StandardOpenOption.WRITE,
                    StandardOpenOption.TRUNCATE_EXISTING, LinkOption.NOFOLLOW_LINKS)) {
                ByteBuffer buffer = StandardCharsets.UTF_8.encode(updated);
                while (buffer.hasRemaining()) output.write(buffer);
                output.force(true);
            }
            // Detect ordinary concurrent edits, including a newly added lock.
            // This is optimistic detection, not a cross-process file lock.
            Source current = readSource(target, fallbackConfigRoot, manager);
            if (locked(current.content())) throw new IOException("Carpet settings became locked while saving.");
            if (!before.equals(current)) throw new IOException("Carpet configuration changed while saving; retry.");
            try {
                Files.move(temporary, target, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
            } catch (AtomicMoveNotSupportedException unavailable) {
                // Same-directory replacement fallback; the original is never
                // opened for writing or truncated. Atomicity depends on the FS.
                Files.move(temporary, target, StandardCopyOption.REPLACE_EXISTING);
            }
        } finally {
            Files.deleteIfExists(temporary);
        }
    }

    public static boolean isLocked(Path worldRoot, Path fallbackConfigRoot, String manager) throws IOException {
        validateManager(manager);
        return locked(readSource(target(worldRoot, manager), fallbackConfigRoot, manager).content());
    }

    private static boolean whitespace(int c) {
        return Character.isWhitespace(c) || Character.isSpaceChar(c);
    }

    private static void validateManager(String manager) throws IOException {
        if (manager == null || !manager.matches("[A-Za-z0-9_.-]+")
                || manager.equals(".") || manager.equals("..") || manager.endsWith(".")) {
            throw new IOException("Invalid Carpet manager identifier.");
        }
        String base = manager.split("\\.", 2)[0].toUpperCase(Locale.ROOT);
        if (base.matches("CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9]")) {
            throw new IOException("Carpet manager identifier is a reserved filesystem name.");
        }
    }

    private static Path target(Path worldRoot, String manager) throws IOException {
        if (worldRoot == null) throw new IOException("A world directory is required.");
        Path realRoot = worldRoot.toRealPath();
        if (!Files.isDirectory(realRoot, LinkOption.NOFOLLOW_LINKS)) {
            throw new IOException("World root is not a directory: " + realRoot);
        }
        return realRoot.resolve(manager + ".conf");
    }

    private static Source readSource(Path target, Path fallbackRoot, String manager) throws IOException {
        String content = readIfPresent(target);
        if (content != null) return new Source(target, content);
        if (fallbackRoot != null) {
            Path realFallback;
            try {
                realFallback = fallbackRoot.toRealPath();
            } catch (NoSuchFileException absent) {
                return new Source(null, "");
            }
            Path fallback = realFallback.resolve("default_" + manager + ".conf");
            String defaults = readIfPresent(fallback);
            if (defaults != null) return new Source(fallback, defaults);
        }
        return new Source(null, "");
    }

    /** A missing file yields null; unsafe files and malformed UTF-8 are errors. */
    private static String readIfPresent(Path file) throws IOException {
        BasicFileAttributes attributes;
        try {
            attributes = Files.readAttributes(file, BasicFileAttributes.class, LinkOption.NOFOLLOW_LINKS);
        } catch (NoSuchFileException absent) {
            return null;
        }
        if (!attributes.isRegularFile() || attributes.isSymbolicLink()) {
            throw new IOException("Config must be a regular file, not a symlink: " + file);
        }
        try (var channel = Files.newByteChannel(file, StandardOpenOption.READ, LinkOption.NOFOLLOW_LINKS);
             var input = Channels.newInputStream(channel)) {
            return StandardCharsets.UTF_8.newDecoder().decode(ByteBuffer.wrap(input.readAllBytes())).toString();
        }
    }

    private static boolean locked(String content) {
        return lines(content).stream().anyMatch(line -> line.text().equalsIgnoreCase("locked"));
    }

    private static String update(String original, String rule, String value) {
        List<Line> lines = lines(original);
        String newline = lines.stream().map(Line::ending).filter(s -> !s.isEmpty()).findFirst().orElse("\n");
        StringBuilder result = new StringBuilder();
        boolean replaced = false;
        for (Line line : lines) {
            String[] fields = line.text().split("\\s+", 2);
            // A bare rule name is not parsed by Carpet: preserve malformed content.
            if (fields.length > 1 && fields[0].equals(rule)) {
                if (!replaced) {
                    result.append(rule).append(' ').append(value).append(line.ending());
                    replaced = true;
                }
            } else {
                result.append(line.text()).append(line.ending());
            }
        }
        if (!replaced) {
            if (!result.isEmpty() && result.charAt(result.length() - 1) != '\n'
                    && result.charAt(result.length() - 1) != '\r') result.append(newline);
            result.append(rule).append(' ').append(value).append(newline);
        }
        return result.toString();
    }

    private static List<Line> lines(String text) {
        List<Line> result = new ArrayList<>();
        int start = 0;
        for (int position = 0; position < text.length(); position++) {
            char current = text.charAt(position);
            if (current == '\r' || current == '\n') {
                int end = position;
                if (current == '\r' && position + 1 < text.length() && text.charAt(position + 1) == '\n') position++;
                result.add(new Line(text.substring(start, end), text.substring(end, position + 1)));
                start = position + 1;
            }
        }
        if (start < text.length()) result.add(new Line(text.substring(start), ""));
        return result;
    }

    private record Line(String text, String ending) {}
    private record Source(Path path, String content) {}
}
