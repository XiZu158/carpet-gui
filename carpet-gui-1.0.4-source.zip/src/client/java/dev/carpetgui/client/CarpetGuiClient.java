package dev.carpetgui.client;

import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import dev.carpetgui.network.GuiProtocol;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

/** Client-only entry point: never reads Carpet's process-global settings directly. */
public final class CarpetGuiClient implements ClientModInitializer {
    public static final ClientState STATE = new ClientState();
    private boolean openRequested;

    @Override
    public void onInitializeClient() {
        KeyMapping key = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.carpet_gui.open", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_G,
                KeyMapping.Category.register(Identifier.fromNamespaceAndPath("carpet_gui", "general"))));
        ClientPlayNetworking.registerGlobalReceiver(GuiProtocol.Response.TYPE,
                (payload, context) -> context.client().execute(() -> STATE.receive(payload)));
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> STATE.reset());
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> STATE.reset());
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, context) -> dispatcher.register(
                LiteralArgumentBuilder.<FabricClientCommandSource>literal("carpetgui").executes(command -> {
                    // Open on the following client tick; the chat screen otherwise closes over it.
                    openRequested = true;
                    return 1;
                })));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            STATE.tick();
            while (key.consumeClick()) {
                if (client.screen == null) openRequested = true;
            }
            if (openRequested) {
                openRequested = false;
                open(client);
            }
        });
    }

    private static void open(Minecraft client) {
        if (client.player == null || client.level == null) return;
        if (!ClientPlayNetworking.canSend(GuiProtocol.Request.TYPE)) {
            client.gui.getChat().addClientSystemMessage(Component.translatable("carpet_gui.unavailable"));
            return;
        }
        client.setScreen(new RulesScreen());
        STATE.refresh(false);
    }
}
