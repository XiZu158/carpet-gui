package dev.carpetgui.client;

import dev.carpetgui.transfer.ImportPlan;
import dev.carpetgui.transfer.ImportRun;
import dev.carpetgui.transfer.RuleConfigFile;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Util;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CompletableFuture;
import java.util.function.Supplier;

/** File selection -> preview -> acknowledged per-rule saves for the currently connected world. */
public final class TransferScreen extends Screen {
    private final RulesScreen parent;
    private final ClientState state = CarpetGuiClient.STATE;
    private final long epoch = state.connectionEpoch();
    private RuleConfigFile.Document document;
    private Path selectedFile;
    private ImportPlan.Mode mode = ImportPlan.Mode.ENABLED_ONLY;
    private ImportPlan plan;
    private ImportRun run;
    private List<Path> files = List.of();
    private TransferList list;
    private final List<Button> idleButtons = new ArrayList<>();
    private Button apply;
    private Button modeButton;
    private int left;
    private int contentWidth;
    private boolean reading;
    private int fileOperation;
    private long observedRevision = -1;
    private Component fileStatus = Component.empty();

    public TransferScreen(RulesScreen parent) { super(Component.translatable("carpet_gui.transfer.title")); this.parent = parent; }

    @Override protected void init() {
        double scroll = list == null ? 0 : list.scrollAmount();
        contentWidth = Math.min(760, width - 24);
        left = (width - contentWidth) / 2;
        idleButtons.clear();
        apply = null;
        modeButton = null;
        int third = (contentWidth - 12) / 3;
        if (document == null) {
            idleButton("carpet_gui.transfer.export_enabled", left, 42, third, state::exportEnabled);
            idleButton("carpet_gui.export", left + third + 6, 42, third, () -> state.refresh(true));
            idleButton("carpet_gui.transfer.folder", left + (third + 6) * 2, 42, contentWidth - (third + 6) * 2, this::openFolder);
            int half = (contentWidth - 6) / 2;
            idleButton("carpet_gui.transfer.reload", left, height - 48, half, this::loadFiles);
            addRenderableWidget(Button.builder(Component.translatable("gui.back"), button -> onClose())
                    .bounds(left + half + 6, height - 48, contentWidth - half - 6, 20).build());
        } else {
            modeButton = idleButton("carpet_gui.import.mode.enabled", left, 42, contentWidth - 106, () -> {
                mode = mode == ImportPlan.Mode.ENABLED_ONLY ? ImportPlan.Mode.ALL_VALUES : ImportPlan.Mode.ENABLED_ONLY;
                list.setScrollAmount(0);
                updatePlan();
            });
            modeButton.setTooltip(Tooltip.create(Component.translatable("carpet_gui.import.mode_hint")));
            idleButton("carpet_gui.refresh", left + contentWidth - 100, 42, 100, () -> state.refresh(false));
            apply = addRenderableWidget(Button.builder(Component.translatable("carpet_gui.import.apply"), button -> {
                if (run != null) { state.stopImport(); return; }
                if (state.startImport(plan, epoch)) { run = state.importRun(); fileStatus = Component.empty(); }
            }).bounds(left, height - 48, third, 20).build());
            idleButton("carpet_gui.transfer.choose", left + third + 6, height - 48, third, () -> {
                document = null; plan = null; run = null; fileStatus = Component.empty();
                list.setScrollAmount(0);
                rebuildWidgets();
                loadFiles();
            });
            addRenderableWidget(Button.builder(Component.translatable("gui.back"), button -> onClose())
                    .bounds(left + (third + 6) * 2, height - 48, contentWidth - (third + 6) * 2, 20).build());
        }
        list = addRenderableWidget(new TransferList(minecraft, font, left, 100, contentWidth, Math.max(34, height - 157)));
        if (document == null) {
            showFiles();
            if (observedRevision == -1) loadFiles();
        } else {
            if (run == null) updatePlan(); else showPlan();
            modeButton.setMessage(Component.translatable(mode == ImportPlan.Mode.ENABLED_ONLY
                    ? "carpet_gui.import.mode.enabled" : "carpet_gui.import.mode.all"));
        }
        list.setScrollAmount(scroll);
        updateButtons();
    }

    private Button idleButton(String key, int x, int y, int width, Runnable action) {
        Button button = addRenderableWidget(Button.builder(Component.translatable(key), ignored -> action.run())
                .bounds(x, y, width, 20).build());
        idleButtons.add(button);
        return button;
    }

    private void updateButtons() {
        boolean idle = !reading && !state.busy();
        idleButtons.forEach(button -> button.active = idle);
        if (modeButton != null) modeButton.active = idle && run == null;
        if (apply != null) {
            apply.setMessage(Component.translatable(run == null ? "carpet_gui.import.apply"
                    : run.active() ? "carpet_gui.import.stop" : "carpet_gui.import.finished"));
            apply.active = run != null ? run.active()
                    : idle && state.canEdit() && state.importSupported() && plan != null && !plan.ready().isEmpty();
        }
    }

    private void updatePlan() {
        plan = ImportPlan.create(document, state.rules(), mode);
        if (modeButton != null) modeButton.setMessage(Component.translatable(mode == ImportPlan.Mode.ENABLED_ONLY
                ? "carpet_gui.import.mode.enabled" : "carpet_gui.import.mode.all"));
        showPlan();
    }

    private void showPlan() {
        list.setLines(plan.rows().stream().<Supplier<TransferList.Line>>map(row -> () -> previewLine(row)).toList());
    }

    private TransferList.Line previewLine(ImportPlan.Row row) {
        var entry = row.entry();
        ImportRun.Result result = run == null ? null : run.result(entry.id());
        String key = result == null ? "carpet_gui.import.row." + row.status().name().toLowerCase(Locale.ROOT)
                : "carpet_gui.import.result." + result.state().name().toLowerCase(Locale.ROOT);
        String label = row.target() == null ? entry.id() : RuleText.name(row.target()) + " (" + entry.id() + ")";
        String values = (row.target() == null ? "?" : row.target().value()) + " → " + entry.value();
        String status = Component.translatable(key).getString();
        String detail = result == null ? row.detail() : result.message();
        String tooltip = label + "\n" + values + "\n" + status;
        if (result != null && result.state() == ImportRun.State.SAVED) tooltip += "\n"
                + Component.translatable("carpet_gui.current", result.value()).getString();
        if (!detail.isBlank()) tooltip += "\n" + detail;
        int color = row.status() != ImportPlan.Status.READY ? 0xFF93A9B8
                : result == null ? 0xFFE6EDF3 : switch (result.state()) {
                    case SAVED -> 0xFF70E3CD;
                    case FAILED, UNKNOWN -> 0xFFFF9C83;
                    default -> 0xFFFFD075;
                };
        return new TransferList.Line(status + " · " + label, values, Component.literal(tooltip), color, null);
    }

    private void showFiles() {
        list.setLines(files.stream().<Supplier<TransferList.Line>>map(path -> () -> new TransferList.Line(
                path.getFileName().toString(), Component.translatable("carpet_gui.transfer.preview").getString(),
                Component.literal(path.toAbsolutePath().toString()), 0xFFE6EDF3, () -> loadFile(path))).toList());
    }

    private void loadFiles() {
        if (reading || document != null) return;
        reading = true;
        int operation = ++fileOperation;
        CompletableFuture.supplyAsync(() -> {
            try {
                Path folder = ClientState.transferDirectory();
                Files.createDirectories(folder);
                record FileInfo(Path path, long modified) {}
                List<FileInfo> found = new ArrayList<>();
                try (var paths = Files.list(folder)) {
                    for (Path path : paths.filter(path -> path.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".txt")).toList()) {
                        if (Files.isRegularFile(path)) found.add(new FileInfo(path, Files.getLastModifiedTime(path).toMillis()));
                    }
                }
                return new FileResult(found.stream().sorted(Comparator.comparingLong(FileInfo::modified).reversed())
                        .limit(512).map(FileInfo::path).toList(), null, "");
            } catch (IOException | RuntimeException exception) { return new FileResult(List.of(), null, String.valueOf(exception.getMessage())); }
        }).thenAccept(result -> minecraft.execute(() -> {
            if (!accept(operation)) return;
            reading = false;
            files = result.files();
            fileStatus = result.error().isBlank() ? Component.empty() : Component.translatable("carpet_gui.transfer.error", result.error());
            showFiles();
        }));
    }

    private record FileResult(List<Path> files, RuleConfigFile.Document document, String error) {}

    private void loadFile(Path path) {
        if (reading || state.busy() || (run != null && run.active())) return;
        reading = true;
        int operation = ++fileOperation;
        CompletableFuture.supplyAsync(() -> {
            try { return new FileResult(List.of(), RuleConfigFile.read(path), ""); }
            catch (IOException | RuntimeException exception) { return new FileResult(List.of(), null, String.valueOf(exception.getMessage())); }
        }).thenAccept(result -> minecraft.execute(() -> {
            if (!accept(operation)) return;
            reading = false;
            if (!result.error().isBlank()) { fileStatus = Component.translatable("carpet_gui.transfer.error", result.error()); return; }
            selectedFile = path;
            document = result.document();
            run = null;
            mode = ImportPlan.Mode.ENABLED_ONLY;
            fileStatus = Component.empty();
            list.setScrollAmount(0);
            rebuildWidgets();
            state.refresh(false);
        }));
    }

    private boolean accept(int operation) {
        return operation == fileOperation && minecraft.screen == this && epoch == state.connectionEpoch() && minecraft.level != null;
    }

    private void openFolder() {
        try { Files.createDirectories(ClientState.transferDirectory()); Util.getPlatform().openPath(ClientState.transferDirectory()); }
        catch (IOException | RuntimeException exception) { fileStatus = Component.translatable("carpet_gui.transfer.error", String.valueOf(exception.getMessage())); }
    }

    @Override public void onFilesDrop(List<Path> paths) {
        if (paths.size() != 1) { fileStatus = Component.translatable("carpet_gui.transfer.one_file"); return; }
        loadFile(paths.getFirst());
    }

    @Override public void tick() {
        if (minecraft.level == null || epoch != state.connectionEpoch()) { minecraft.setScreen(null); return; }
        if (observedRevision != state.revision()) {
            observedRevision = state.revision();
            if (document != null && run == null) updatePlan();
            else if (document == null && !state.busy()) loadFiles();
        }
        updateButtons();
    }

    @Override public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        graphics.fill(left - 6, 6, left + contentWidth + 6, height - 4, 0xD0141C24);
        graphics.centeredText(font, title, width / 2, 12, 0xFF70E3CD);
        Component destination = Component.translatable("carpet_gui.transfer.world", state.world());
        if (selectedFile != null && document != null) destination = destination.copy().append(" · " + selectedFile.getFileName());
        drawLine(graphics, destination, 27, mouseX, mouseY);
        if (document == null) {
            drawLine(graphics, Component.translatable("carpet_gui.transfer.files_hint"), 68, mouseX, mouseY);
            drawLine(graphics, Component.literal(ClientState.transferDirectory().toString()), 83, mouseX, mouseY);
        } else {
            Component summary = run == null ? Component.translatable("carpet_gui.import.preview_count", plan.ready().size(), plan.rows().size() - plan.ready().size())
                    : state.importSummary(run);
            drawLine(graphics, summary, 68, mouseX, mouseY);
            drawLine(graphics, Component.translatable(mode == ImportPlan.Mode.ENABLED_ONLY
                    ? "carpet_gui.import.enabled_hint" : "carpet_gui.import.all_hint"), 83, mouseX, mouseY);
        }
        super.extractRenderState(graphics, mouseX, mouseY, partialTick);
        if (document == null && files.isEmpty() && !reading)
            graphics.centeredText(font, Component.translatable("carpet_gui.transfer.no_files"), width / 2, 112, 0xFFBFCAD3);
        Component status = !fileStatus.getString().isBlank() ? fileStatus : reading ? Component.translatable("carpet_gui.transfer.reading")
                : document != null && !state.importSupported() && !state.busy() ? Component.translatable("carpet_gui.import.unsupported") : state.status();
        drawLine(graphics, status, height - 21, mouseX, mouseY);
        if (document != null && mouseY >= 24 && mouseY < 39) {
            graphics.setTooltipForNextFrame(font, Component.literal(selectedFile.toAbsolutePath() + "\n"
                    + Component.translatable("carpet_gui.transfer.source_world", document.world()).getString()), mouseX, mouseY);
        }
    }

    private void drawLine(GuiGraphicsExtractor graphics, Component text, int y, int mouseX, int mouseY) {
        graphics.text(font, font.plainSubstrByWidth(text.getString(), contentWidth), left, y, 0xFFBFCAD3);
        if (mouseX >= left && mouseX < left + contentWidth && mouseY >= y && mouseY < y + 10)
            graphics.setTooltipForNextFrame(font, text, mouseX, mouseY);
    }

    @Override public void onClose() { if (run != null && run.active()) state.stopImport(); minecraft.setScreen(parent); }
    @Override public boolean isPauseScreen() { return false; }
}
