package dev.carpetgui.client;

import com.google.gson.Gson;
import com.google.gson.JsonParseException;
import dev.carpetgui.model.RuleView;
import dev.carpetgui.network.GuiProtocol;
import dev.carpetgui.transfer.ImportPlan;
import dev.carpetgui.transfer.ImportRun;
import dev.carpetgui.transfer.RuleConfigFile;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

/** All mutable state is accessed on the client thread; exports use an immutable snapshot. */
public final class ClientState {
    private static final Gson GSON = new Gson();
    private static final long TIMEOUT_NANOS = 30_000_000_000L;
    private static final long REQUEST_INTERVAL_NANOS = 250_000_000L;
    private static final int MAX_PAGES = 4096;
    private static final int MAX_RULES = 65_536;
    private final Map<Integer, Page> incoming = new HashMap<>();
    private List<RuleView> rules = List.of();
    private String world = "";
    private boolean canEdit;
    private boolean busy;
    private boolean exportRequested;
    private boolean exportEnabledOnly;
    private boolean importSupported;
    private boolean finishingImport;
    private ImportRun importRun;
    private String activeAction = "";
    private int requestId;
    private int expectedPages = -1;
    private long requestStarted;
    private long lastSent;
    private GuiProtocol.Request queuedRequest;
    private long revision;
    private long connectionEpoch;
    private Component status = Component.translatable("carpet_gui.loading");

    private record Page(String world, boolean canEdit, String message, boolean error, int page, int pages,
                        List<RuleView> rules, int transferVersion) {}

    public List<RuleView> rules() { return rules; }
    public String world() { return world; }
    public boolean canEdit() { return canEdit; }
    public boolean busy() { return busy || importing(); }
    public boolean importing() { return importRun != null && importRun.active(); }
    public boolean importSupported() { return importSupported; }
    public ImportRun importRun() { return importRun; }
    public long connectionEpoch() { return connectionEpoch; }
    public long revision() { return revision; }
    public Component status() { return status; }

    public RuleView find(String manager, String name) {
        return rules.stream().filter(r -> r.manager().equals(manager) && r.name().equals(name)).findFirst().orElse(null);
    }

    public void reset() {
        RuleText.invalidate();
        connectionEpoch++;
        requestId++; // Late packets from the old connection cannot match a new request.
        rules = List.of();
        world = "";
        canEdit = false;
        busy = false;
        exportRequested = false;
        exportEnabledOnly = false;
        importSupported = false;
        finishingImport = false;
        importRun = null;
        activeAction = "";
        incoming.clear();
        expectedPages = -1;
        queuedRequest = null;
        lastSent = 0;
        status = Component.translatable("carpet_gui.loading");
        revision++;
    }

    public void refresh(boolean export) {
        if (busy()) return;
        exportEnabledOnly = false;
        request("snapshot", "", "", "", export);
    }

    public void exportEnabled() {
        if (busy()) return;
        exportEnabledOnly = true;
        request("snapshot", "", "", "", true);
    }

    public void apply(RuleView rule, String value) {
        if (!canEdit || rule.locked() || busy()) return;
        request("set", rule.manager(), rule.name(), value, false);
    }

    public boolean startImport(ImportPlan plan, long expectedEpoch) {
        if (busy() || !canEdit || !importSupported || connectionEpoch != expectedEpoch || plan.ready().isEmpty()) return false;
        importRun = new ImportRun(plan.ready());
        sendNextImport();
        return true;
    }

    public void stopImport() {
        if (!importing()) return;
        boolean unsent = queuedRequest != null;
        importRun.stop(Component.translatable("carpet_gui.import.stopped").getString(), unsent);
        if (unsent) { queuedRequest = null; busy = false; }
        revision++;
        if (!busy) finishImport();
    }

    private void sendNextImport() {
        var entry = importRun.next();
        if (entry == null) { finishImport(); return; }
        request(GuiProtocol.IMPORT_ACTION, entry.manager(), entry.rule(), entry.value(), false);
        if (busy) status = Component.translatable("carpet_gui.import.progress",
                importRun.count(ImportRun.State.SAVED) + importRun.count(ImportRun.State.FAILED), importRun.size());
    }

    private void finishImport() {
        finishingImport = true;
        request("snapshot", "", "", "", false);
    }

    public Component importSummary(ImportRun run) {
        return Component.translatable("carpet_gui.import.summary", run.count(ImportRun.State.SAVED),
                run.count(ImportRun.State.FAILED), run.count(ImportRun.State.UNKNOWN), run.count(ImportRun.State.CANCELLED));
    }

    private void request(String action, String manager, String rule, String value, boolean export) {
        if (busy) return;
        if (manager.length() > 256 || rule.length() > 256 || value.length() > GuiProtocol.MAX_VALUE_LENGTH) {
            fail(Component.literal("规则标识过长，或值超过 4096 字符，无法发送。"));
            return;
        }
        if (Minecraft.getInstance().getConnection() == null || !ClientPlayNetworking.canSend(GuiProtocol.Request.TYPE)) {
            fail(Component.translatable("carpet_gui.unavailable"));
            return;
        }
        incoming.clear();
        expectedPages = -1;
        busy = true;
        activeAction = action;
        exportRequested = export;
        requestStarted = System.nanoTime();
        status = Component.translatable("carpet_gui.loading");
        revision++;
        queuedRequest = new GuiProtocol.Request(++requestId, action, manager, rule, value);
        sendQueuedRequest();
    }

    public void tick() {
        sendQueuedRequest();
        if (busy && System.nanoTime() - requestStarted > TIMEOUT_NANOS) {
            fail(Component.translatable("carpet_gui.timeout"));
        }
    }

    private void sendQueuedRequest() {
        if (queuedRequest == null || (lastSent != 0 && System.nanoTime() - lastSent < REQUEST_INTERVAL_NANOS)) return;
        if (Minecraft.getInstance().getConnection() == null || !ClientPlayNetworking.canSend(GuiProtocol.Request.TYPE)) {
            fail(Component.translatable("carpet_gui.unavailable"));
            return;
        }
        GuiProtocol.Request request = queuedRequest;
        queuedRequest = null;
        lastSent = System.nanoTime();
        requestStarted = lastSent;
        ClientPlayNetworking.send(request);
    }

    public void receive(GuiProtocol.Response response) {
        if (!busy || response.requestId() != requestId) return;
        try {
            if (activeAction.equals(GuiProtocol.IMPORT_ACTION)) {
                GuiProtocol.ImportReply reply = GSON.fromJson(response.json(), GuiProtocol.ImportReply.class);
                if (reply == null || !GuiProtocol.IMPORT_ACTION.equals(reply.operation()) || reply.manager() == null
                        || reply.rule() == null || reply.message() == null || reply.value() == null || importRun == null)
                    throw new JsonParseException("Invalid import acknowledgement");
                importRun.acknowledge(reply.manager(), reply.rule(), reply.success(), reply.value(), reply.message(), reply.stop());
                busy = false;
                // Wait after the acknowledgement too: a lagging server may have processed the previous request late.
                lastSent = System.nanoTime();
                revision++;
                sendNextImport();
                return;
            }
            Page page = GSON.fromJson(response.json(), Page.class);
            if (page != null && page.error()) {
                canEdit = page.canEdit();
                fail(page.message() == null || page.message().isBlank()
                        ? Component.translatable("carpet_gui.invalid_response") : Component.literal(page.message()));
                return;
            }
            if (page == null || page.world() == null || page.rules() == null || page.pages() < 1
                    || page.pages() > MAX_PAGES || page.page() < 0 || page.page() >= page.pages()
                    || page.rules().size() > 16
                    || (expectedPages != -1 && expectedPages != page.pages())) {
                throw new JsonParseException("Invalid snapshot page");
            }
            for (RuleView rule : page.rules()) {
                if (rule == null || rule.manager() == null || rule.managerName() == null || rule.name() == null
                        || rule.description() == null || rule.categories() == null || rule.options() == null
                        || rule.type() == null || rule.value() == null || rule.defaultValue() == null
                        || rule.categories().contains(null) || rule.options().contains(null)) {
                    throw new JsonParseException("Invalid rule");
                }
            }
            expectedPages = page.pages();
            incoming.putIfAbsent(page.page(), page);
            if (incoming.size() != expectedPages) return;
            List<RuleView> collected = new ArrayList<>();
            Page first = incoming.get(0);
            for (int i = 0; i < expectedPages; i++) {
                Page part = incoming.get(i);
                if (!part.world().equals(first.world()) || part.canEdit() != first.canEdit()) {
                    throw new JsonParseException("Inconsistent snapshot");
                }
                collected.addAll(part.rules());
                if (collected.size() > MAX_RULES) throw new JsonParseException("Snapshot is too large");
            }
            collected.sort(Comparator.comparing(RuleView::manager).thenComparing(RuleView::name));
            rules = List.copyOf(collected);
            world = first.world();
            canEdit = first.canEdit();
            importSupported = first.transferVersion() >= GuiProtocol.TRANSFER_VERSION;
            busy = false;
            // Also space the first import after a slow snapshot response to avoid a server-side rate rejection.
            lastSent = System.nanoTime();
            incoming.clear();
            status = first.message() == null || first.message().isBlank()
                    ? Component.translatable("carpet_gui.loaded", rules.size()) : Component.literal(first.message());
            if (finishingImport) {
                finishingImport = false;
                status = importSummary(importRun);
            }
            revision++;
            if (exportRequested) {
                exportRequested = false;
                exportSnapshot(world, rules, connectionEpoch, requestId, exportEnabledOnly);
            }
        } catch (RuntimeException exception) {
            fail(Component.translatable("carpet_gui.invalid_response"));
        }
    }

    private void fail(Component message) {
        busy = false;
        exportRequested = false;
        incoming.clear();
        queuedRequest = null;
        if (importing()) {
            Component uncertain = Component.translatable("carpet_gui.import.uncertain", message.getString());
            importRun.unknown(uncertain.getString());
            message = uncertain;
        }
        finishingImport = false;
        status = message;
        revision++;
    }

    public static Path transferDirectory() {
        return FabricLoader.getInstance().getConfigDir().resolve("carpet-gui").resolve("exports");
    }

    private void exportSnapshot(String snapshotWorld, List<RuleView> snapshotRules, long epoch, int id, boolean enabledOnly) {
        status = Component.translatable("carpet_gui.exporting");
        CompletableFuture.supplyAsync(() -> {
            try {
                Path directory = transferDirectory();
                Files.createDirectories(directory);
                String safeWorld = snapshotWorld.replaceAll("[^\\p{L}\\p{N}._-]", "_");
                if (safeWorld.isBlank()) safeWorld = "world";
                if (safeWorld.length() > 60) safeWorld = safeWorld.substring(0, 60);
                String stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss-SSS"));
                Path target = directory.resolve((enabledOnly ? "carpet-enabled-" : "carpet-") + safeWorld + "-" + stamp + "-"
                        + UUID.randomUUID().toString().substring(0, 8) + ".txt");
                Files.writeString(target, RuleConfigFile.format(snapshotWorld, snapshotRules, enabledOnly),
                        StandardCharsets.UTF_8, StandardOpenOption.CREATE_NEW);
                return Component.translatable("carpet_gui.exported", target.toAbsolutePath().toString());
            } catch (IOException | RuntimeException exception) {
                return Component.translatable("carpet_gui.export_failed", String.valueOf(exception.getMessage()));
            }
        }).thenAccept(message -> Minecraft.getInstance().execute(() -> {
            if (connectionEpoch == epoch && requestId == id) {
                status = message;
                revision++;
                if (Minecraft.getInstance().player != null) {
                    Minecraft.getInstance().gui.getChat().addClientSystemMessage(message);
                }
            }
        }));
    }

}
