package dev.carpetgui.client;

import dev.carpetgui.model.RuleActivity;
import dev.carpetgui.model.RuleView;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.ContainerObjectSelectionList;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.narration.NarratableEntry;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/** Searchable, scrollable overview. Filters affect presentation only, never exports. */
public final class RulesScreen extends Screen {
    private final ClientState state = CarpetGuiClient.STATE;
    private List<RuleView> filtered = List.of();
    private String manager = "";
    private String category = "";
    private String query = "";
    private Tab tab = Tab.ALL;
    private int left;
    private int contentWidth;
    private long observedRevision = -1;
    private EditBox search;
    private Button managerButton;
    private Button categoryButton;
    private Button allTab;
    private Button enabledTab;
    private Button modifiedTab;
    private RuleList ruleList;
    private Button refresh;
    private Button export;

    private enum Tab { ALL, ENABLED, MODIFIED }

    public RulesScreen() {
        super(Component.translatable("carpet_gui.title"));
    }

    @Override
    protected void init() {
        double previousScroll = ruleList == null ? 0 : ruleList.scrollAmount();
        contentWidth = Math.min(760, width - 24);
        left = (width - contentWidth) / 2;
        int third = (contentWidth - 12) / 3;
        allTab = addRenderableWidget(Button.builder(Component.empty(), button -> selectTab(Tab.ALL))
                .bounds(left, 42, third, 20).build());
        enabledTab = addRenderableWidget(Button.builder(Component.empty(), button -> selectTab(Tab.ENABLED))
                .bounds(left + third + 6, 42, third, 20)
                .tooltip(Tooltip.create(Component.translatable("carpet_gui.tab.enabled_hint"))).build());
        modifiedTab = addRenderableWidget(Button.builder(Component.empty(), button -> selectTab(Tab.MODIFIED))
                .bounds(left + (third + 6) * 2, 42, contentWidth - (third + 6) * 2, 20)
                .tooltip(Tooltip.create(Component.translatable("carpet_gui.tab.modified_hint"))).build());
        int half = (contentWidth - 6) / 2;
        managerButton = addRenderableWidget(Button.builder(Component.empty(), button -> {
            manager = cycle(manager, Stream.concat(Stream.of(""), state.rules().stream()
                    .map(RuleView::manager).distinct().sorted()).toList());
            ruleList.setScrollAmount(0);
            refreshRows();
        }).bounds(left, 66, half, 20).build());
        categoryButton = addRenderableWidget(Button.builder(Component.empty(), button -> {
            category = cycle(category, Stream.concat(Stream.of(""), state.rules().stream()
                    .flatMap(rule -> rule.categories().stream()).distinct().sorted()).toList());
            ruleList.setScrollAmount(0);
            refreshRows();
        }).bounds(left + half + 6, 66, contentWidth - half - 6, 20).build());
        search = addRenderableWidget(new EditBox(font, left, 92, contentWidth, 20,
                Component.translatable("carpet_gui.search")));
        search.setMaxLength(256);
        search.setHint(Component.translatable("carpet_gui.search"));
        search.setValue(query);
        search.setResponder(value -> {
            query = value;
            ruleList.setScrollAmount(0);
            refreshRows();
        });
        ruleList = addRenderableWidget(new RuleList());
        refresh = addRenderableWidget(Button.builder(Component.translatable("carpet_gui.refresh"),
                button -> state.refresh(false)).bounds(left, height - 50, third, 20).build());
        export = addRenderableWidget(Button.builder(Component.translatable("carpet_gui.transfer.open"),
                button -> minecraft.setScreen(new TransferScreen(this))).bounds(left + third + 6, height - 50, third, 20)
                .tooltip(Tooltip.create(Component.translatable("carpet_gui.transfer.open_hint"))).build());
        addRenderableWidget(Button.builder(Component.translatable("gui.done"), button -> onClose())
                .bounds(left + (third + 6) * 2, height - 50, contentWidth - (third + 6) * 2, 20).build());
        refreshRows();
        // Screen.init runs again after returning from details and when the window is resized.
        ruleList.setScrollAmount(previousScroll);
    }

    private void refreshRows() {
        if (managerButton == null) return;
        if (!manager.isEmpty() && state.rules().stream().noneMatch(rule -> rule.manager().equals(manager))) manager = "";
        if (!category.isEmpty() && state.rules().stream().noneMatch(rule -> rule.categories().contains(category))) category = "";
        String lowered = query.toLowerCase(Locale.ROOT).trim();
        List<RuleView> matching = state.rules().stream()
                .filter(rule -> manager.isEmpty() || rule.manager().equals(manager))
                .filter(rule -> category.isEmpty() || rule.categories().contains(category))
                .filter(rule -> lowered.isEmpty() || searchableText(rule).toLowerCase(Locale.ROOT).contains(lowered))
                .toList();
        allTab.setMessage(Component.translatable("carpet_gui.tab.all", matching.size()));
        enabledTab.setMessage(Component.translatable("carpet_gui.tab.enabled", matching.stream().filter(RuleActivity::isEnabled).count()));
        modifiedTab.setMessage(Component.translatable("carpet_gui.tab.modified", matching.stream().filter(RuleActivity::isModified).count()));
        allTab.active = tab != Tab.ALL;
        enabledTab.active = tab != Tab.ENABLED;
        modifiedTab.active = tab != Tab.MODIFIED;
        filtered = matching.stream().filter(rule -> switch (tab) {
            case ALL -> true;
            case ENABLED -> RuleActivity.isEnabled(rule);
            case MODIFIED -> RuleActivity.isModified(rule);
        }).toList();
        managerButton.setMessage(Component.translatable("carpet_gui.manager", manager.isEmpty()
                ? Component.translatable("carpet_gui.all").getString() : manager));
        categoryButton.setMessage(Component.translatable("carpet_gui.category", category.isEmpty()
                ? Component.translatable("carpet_gui.all").getString() : selectedCategoryName()));
        managerButton.setTooltip(Tooltip.create(managerButton.getMessage()));
        categoryButton.setTooltip(Tooltip.create(categoryButton.getMessage().copy()
                .append(category.isEmpty() ? "" : " (" + category + ")")));
        ruleList.replaceRules(filtered);
        refresh.active = !state.busy();
        export.active = !state.busy();
        observedRevision = state.revision();
    }

    private void selectTab(Tab selected) {
        tab = selected;
        ruleList.setScrollAmount(0);
        refreshRows();
    }

    private String selectedCategoryName() {
        String categoryManager = manager.isEmpty()
                ? state.rules().stream().filter(rule -> rule.categories().contains(category))
                    .map(RuleView::manager).findFirst().orElse("carpet")
                : manager;
        return RuleText.category(categoryManager, category);
    }

    private static String translatedCategories(RuleView rule) {
        return rule.categories().stream().map(value -> RuleText.category(rule.manager(), value))
                .collect(Collectors.joining(", "));
    }

    private static String searchableText(RuleView rule) {
        return RuleText.name(rule) + " " + RuleText.description(rule) + " " + rule.manager() + ":" + rule.name()
                + " " + rule.description() + " " + rule.managerName() + " " + String.join(" ", rule.categories())
                + " " + translatedCategories(rule);
    }

    private static Component ruleTooltip(RuleView rule) {
        return Component.literal(RuleText.name(rule) + "\n" + rule.manager() + ":" + rule.name() + " = "
                + rule.value() + "\n" + translatedCategories(rule) + "\n" + RuleText.description(rule));
    }

    private static String cycle(String current, List<String> values) {
        return values.get((values.indexOf(current) + 1) % values.size());
    }

    @Override
    public void tick() {
        if (minecraft.level == null) { onClose(); return; }
        if (observedRevision != state.revision()) refreshRows();
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        graphics.fill(left - 6, 6, left + contentWidth + 6, height - 4, 0xB0141C24);
        graphics.centeredText(font, title, width / 2, 12, 0xFF70E3CD);
        Component worldLabel = Component.translatable("carpet_gui.world", state.world(),
                Component.translatable(state.canEdit() ? "carpet_gui.editable" : "carpet_gui.readonly"));
        graphics.centeredText(font, font.plainSubstrByWidth(worldLabel.getString(), contentWidth), width / 2, 27, 0xFFBFCAD3);
        Button selectedTab = switch (tab) {
            case ALL -> allTab;
            case ENABLED -> enabledTab;
            case MODIFIED -> modifiedTab;
        };
        graphics.fill(selectedTab.getX(), 63, selectedTab.getX() + selectedTab.getWidth(), 65, 0xFF70E3CD);
        super.extractRenderState(graphics, mouseX, mouseY, partialTick);
        if (filtered.isEmpty() && !state.busy()) {
            graphics.centeredText(font, Component.translatable("carpet_gui.no_rules"), width / 2, 129, 0xFFBFCAD3);
        }
        Component listHint = Component.translatable("carpet_gui.list_scroll", filtered.size());
        graphics.centeredText(font, font.plainSubstrByWidth(listHint.getString(), contentWidth),
                width / 2, height - 65, 0xFF93A9B8);
        drawStatus(graphics, mouseX, mouseY);
    }

    /** Vanilla handles wheel input, clipping, scrollbar dragging and keyboard focus scrolling. */
    private final class RuleList extends ContainerObjectSelectionList<RuleEntry> {
        private static final int ROW_HEIGHT = 30;

        private RuleList() {
            super(RulesScreen.this.minecraft, contentWidth, Math.max(30, RulesScreen.this.height - 190), 118, ROW_HEIGHT);
            setX(left);
            centerListVertically = false;
        }

        private void replaceRules(List<RuleView> rules) {
            double previousScroll = scrollAmount();
            setFocused((GuiEventListener) null);
            clearEntries();
            for (int index = 0; index < rules.size(); index++) {
                addEntry(new RuleEntry(rules.get(index), index % 2 == 0));
            }
            // A refreshed snapshot may contain fewer rows; the native setter clamps the offset.
            setScrollAmount(previousScroll);
        }

        @Override public int getRowLeft() { return getX(); }
        @Override public int getRowWidth() { return getWidth() - 12; }
        @Override protected int scrollBarX() { return getRight() - scrollbarWidth(); }
        @Override protected double scrollRate() { return ROW_HEIGHT; }

        @Override
        protected void extractListBackground(GuiGraphicsExtractor graphics) {
            graphics.fill(getX(), getY(), getRight(), getBottom(), 0x442A3844);
        }

        @Override protected void extractListSeparators(GuiGraphicsExtractor graphics) {}
    }

    private final class RuleEntry extends ContainerObjectSelectionList.Entry<RuleEntry> {
        private final RuleView rule;
        private final boolean alternate;
        private final Button valueButton;
        private final String displayName;
        private final Component tooltip;

        private RuleEntry(RuleView rule, boolean alternate) {
            this.rule = rule;
            this.alternate = alternate;
            displayName = RuleText.name(rule);
            tooltip = ruleTooltip(rule);
            valueButton = Button.builder(Component.literal(rule.value()), ignored ->
                    minecraft.setScreen(new RuleEditScreen(RulesScreen.this, rule)))
                    .createNarration(supplier -> Component.literal(displayName + ", " + rule.value())).build();
        }

        private void positionButton() {
            if (valueButton == null) return;
            int valueWidth = Math.min(180, getWidth() / 3);
            valueButton.setRectangle(valueWidth, 20, getX() + getWidth() - valueWidth - 2, getY() + 3);
        }

        // Keep hitboxes aligned immediately on scroll, before the next rendered frame.
        @Override public void setX(int x) { super.setX(x); positionButton(); }
        @Override public void setY(int y) { super.setY(y); positionButton(); }
        @Override public void setWidth(int width) { super.setWidth(width); positionButton(); }
        @Override public List<? extends GuiEventListener> children() { return List.of(valueButton); }
        @Override public List<? extends NarratableEntry> narratables() { return List.of(valueButton); }

        @Override
        public void extractContent(GuiGraphicsExtractor graphics, int mouseX, int mouseY, boolean hovered, float partialTick) {
            int x = getX();
            int y = getY();
            graphics.fill(x, y, x + getWidth(), y + getHeight() - 3, alternate ? 0x443D5060 : 0x222A3844);
            int textWidth = valueButton.getX() - x - 8;
            int color = RuleActivity.isModified(rule) ? 0xFFFFD075 : 0xFFE6EDF3;
            graphics.text(font, font.plainSubstrByWidth(displayName, textWidth), x + 4, y + 3, color);
            graphics.text(font, font.plainSubstrByWidth(rule.manager() + ":" + rule.name(), textWidth),
                    x + 4, y + 15, 0xFF93A9B8);
            // Partial rows must not hover over the fixed header or footer outside the list.
            boolean inList = ruleList.isMouseOver(mouseX, mouseY);
            valueButton.extractRenderState(graphics, inList ? mouseX : -1, inList ? mouseY : -1, partialTick);
            if (hovered) graphics.setTooltipForNextFrame(font, tooltip, mouseX, mouseY);
        }
    }

    private void drawStatus(GuiGraphicsExtractor graphics, int mouseX, int mouseY) {
        graphics.text(font, font.plainSubstrByWidth(state.status().getString(), contentWidth), left, height - 22, 0xFFBFCAD3);
        if (mouseY >= height - 25 && mouseX >= left && mouseX <= left + contentWidth) {
            graphics.setTooltipForNextFrame(font, state.status(), mouseX, mouseY);
        }
    }

    @Override public boolean isPauseScreen() { return false; }
}
