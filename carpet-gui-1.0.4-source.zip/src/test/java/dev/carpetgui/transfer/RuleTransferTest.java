package dev.carpetgui.transfer;

import dev.carpetgui.model.RuleView;
import dev.carpetgui.storage.WorldConfigStore;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Migration checks cover the actual export format, partial writes, cancellation and independent world files. */
public final class RuleTransferTest {
    private static int checks;

    public static void main(String[] args) throws Exception {
        textRoundTrips();
        rejectMalformedFiles();
        planAgainstDestination();
        acknowledgementsAndStops();
        Path directory = Files.createTempDirectory("carpet-gui-transfer-test-");
        try { fileAndWorldMigration(directory); }
        finally {
            try (var paths = Files.walk(directory)) {
                for (Path path : paths.sorted(Comparator.reverseOrder()).toList()) Files.deleteIfExists(path);
            }
        }
        System.out.println("RuleTransferTest: " + checks + " checks passed (legacy exports, previews, acknowledgements, stops and world migration).");
    }

    private static void textRoundTrips() throws Exception {
        List<RuleView> rules = List.of(rule("carpet", "flag", "boolean", "true", false),
                rule("addon", "text", "String", "路径\\配置 = 中文\t尾部 ", false),
                rule("carpet", "off", "Boolean", "false", false));
        var all = RuleConfigFile.parse(RuleConfigFile.format("世界 A\\B\n下一行", rules, false));
        equal("世界 A\\B\n下一行", all.world(), "world metadata round trip");
        equal(3, all.entries().size(), "complete export includes disabled and text entries");
        equal("路径\\配置 = 中文\t尾部 ", all.entries().getFirst().value(), "escaping, equals and trailing spaces survive");
        var enabled = RuleConfigFile.parse(RuleConfigFile.format("A", rules, true));
        equal(1, enabled.entries().size(), "enabled export filters");
        equal("carpet:flag", enabled.entries().getFirst().id(), "stable rule identity");
        String legacy = "\uFEFF# Carpet GUI — complete server snapshot\r\n# World: 旧存档\r\n"
                + "# Rules: 2\r\n\r\n[carpet] # carpet\r\ncarpet:flag = true\r\ncarpet:empty = \r\n";
        var parsed = RuleConfigFile.parse(legacy);
        equal("旧存档", parsed.world(), "legacy world with BOM and CRLF");
        equal(2, parsed.entries().size(), "legacy 1.0.3 text accepted");
        equal("", parsed.entries().get(1).value(), "empty string preserved");
        equal(6, parsed.entries().getFirst().line(), "line number for diagnostics");
        equal(0, RuleConfigFile.parse(RuleConfigFile.format("empty", List.of(), true)).entries().size(), "empty enabled export");
        equal(4096, RuleConfigFile.parse("carpet:long = " + "x".repeat(4096)).entries().getFirst().value().length(), "value boundary");
        StringBuilder maximum = new StringBuilder();
        for (int i = 0; i < RuleConfigFile.MAX_ENTRIES; i++) maximum.append("carpet:r").append(i).append(" = true\n");
        equal(RuleConfigFile.MAX_ENTRIES, RuleConfigFile.parse(maximum.toString()).entries().size(), "entry count boundary");
        expect(IOException.class, () -> RuleConfigFile.parse(maximum + "carpet:extra = true"), "too many entries");
    }

    private static void rejectMalformedFiles() throws Exception {
        for (String input : List.of("/carpet flag true", "flag true", "carpet:flag true", "flag = true", ":flag = true",
                "carpet: = true", "carpet:flag = x\\", "carpet:flag = x\\q", "[carpet", "carpet:flag = true\ncarpet:flag = false"))
            expect(IOException.class, () -> RuleConfigFile.parse(input), "reject malformed/ambiguous file");
        expect(IOException.class, () -> RuleConfigFile.parse("carpet:long = " + "x".repeat(4097)), "overlong value");
        expect(IOException.class, () -> RuleConfigFile.parse("a".repeat(257) + ":flag = true"), "overlong manager");
        expect(IOException.class, () -> RuleConfigFile.parse("carpet:" + "x".repeat(257) + " = true"), "overlong rule");
        expect(IOException.class, () -> RuleConfigFile.parse("#" + "中".repeat(RuleConfigFile.MAX_FILE_BYTES / 3 + 1)), "UTF-8 byte size bound");
    }

    private static void planAgainstDestination() throws Exception {
        var document = RuleConfigFile.parse("carpet:flag = true\ncarpet:off = false\ncarpet:number = 5\n"
                + "carpet:command = 0\naddon:flag = true\nmissing:flag = true\ncarpet:locked = true\ncarpet:bad = x\\ny\n");
        List<RuleView> targets = List.of(rule("carpet", "flag", "boolean", "false", false),
                rule("carpet", "off", "boolean", "true", false), rule("carpet", "number", "int", "2", false),
                command("false"), rule("addon", "flag", "Boolean", "false", false),
                rule("carpet", "locked", "boolean", "false", true), rule("carpet", "bad", "String", "x", false),
                rule("carpet", "notInFile", "boolean", "true", false));
        ImportPlan plan = ImportPlan.create(document, targets, ImportPlan.Mode.ENABLED_ONLY);
        equal(List.of("carpet:flag", "carpet:command", "addon:flag"), plan.ready().stream().map(RuleConfigFile.Entry::id).toList(),
                "enabled-only chooses requested values, including command level zero and extension namespace");
        equal(ImportPlan.Status.NOT_ENABLED, plan.rows().get(1).status(), "does not disable existing enabled rule");
        equal(ImportPlan.Status.NOT_ENABLED, plan.rows().get(2).status(), "numeric settings not guessed enabled");
        equal(ImportPlan.Status.MISSING, plan.rows().get(5).status(), "unknown extension skipped");
        equal(ImportPlan.Status.LOCKED, plan.rows().get(6).status(), "locked target skipped");
        equal(ImportPlan.Status.INVALID, plan.rows().get(7).status(), "non-persistable value skipped");
        equal(8, plan.rows().size(), "unlisted target not included");
        ImportPlan complete = ImportPlan.create(document, targets, ImportPlan.Mode.ALL_VALUES);
        equal(5, complete.ready().size(), "explicit all-values mode includes false and numbers");
        equal("false", complete.ready().get(1).value(), "false value retained in all-values mode");
        equal("false", targets.getFirst().value(), "preview does not mutate destination");
        equal(0, ImportPlan.create(document, List.of(), ImportPlan.Mode.ALL_VALUES).ready().size(), "empty destination");
        equal(0, ImportPlan.create(new RuleConfigFile.Document("A", List.of()), targets, ImportPlan.Mode.ALL_VALUES).ready().size(), "empty source");
        expect(UnsupportedOperationException.class, () -> document.entries().clear(), "immutable parsed document");
        expect(UnsupportedOperationException.class, () -> plan.rows().clear(), "immutable plan");
    }

    private static void acknowledgementsAndStops() throws Exception {
        var entries = RuleConfigFile.parse("carpet:a = true\ncarpet:b = true\ncarpet:c = true").entries();
        ImportRun run = new ImportRun(entries);
        equal(3L, run.count(ImportRun.State.PENDING), "initial pending count");
        equal("a", run.next().rule(), "first in order");
        expect(IllegalStateException.class, run::next, "no second request before acknowledgement");
        expect(IllegalArgumentException.class, () -> run.acknowledge("other", "a", true, "true", "wrong", false), "mismatched ack rejected");
        equal(0L, run.count(ImportRun.State.SAVED), "unconfirmed is not success");
        run.acknowledge("carpet", "a", true, "normalized", "saved", false);
        equal("normalized", run.result("carpet:a").value(), "canonical saved value recorded");
        equal("b", run.next().rule(), "next after ack");
        run.acknowledge("carpet", "b", false, "", "validator rejected", false);
        equal("c", run.next().rule(), "ordinary validation failure does not stop unrelated entries");
        run.acknowledge("carpet", "c", true, "true", "saved", false);
        equal(false, run.active(), "finished");
        require(run.next() == null, "no replay on finish");
        equal(2L, run.count(ImportRun.State.SAVED), "partial success count");
        equal(1L, run.count(ImportRun.State.FAILED), "failure count");
        ImportRun cancel = new ImportRun(entries);
        cancel.next(); cancel.stop("user cancelled", false);
        equal(true, cancel.active(), "sent request still awaits acknowledgement");
        equal(2L, cancel.count(ImportRun.State.CANCELLED), "remaining requests cancelled");
        cancel.acknowledge("carpet", "a", true, "true", "saved after stop", false);
        require(cancel.next() == null && !cancel.active(), "no work after stopped in-flight request");
        ImportRun queued = new ImportRun(entries);
        queued.next(); queued.stop("not sent", true);
        equal(3L, queued.count(ImportRun.State.CANCELLED), "queued unsent request cancelled too");
        equal(false, queued.active(), "unsent cancellation complete");
        ImportRun timeout = new ImportRun(entries);
        timeout.next(); timeout.unknown("response lost");
        equal(1L, timeout.count(ImportRun.State.UNKNOWN), "timeout does not claim failure or success");
        equal(2L, timeout.count(ImportRun.State.CANCELLED), "timeout stops remainder");
        require(timeout.next() == null, "timeout never retries potentially saved write");
        ImportRun revoked = new ImportRun(entries);
        revoked.next(); revoked.acknowledge("carpet", "a", false, "", "permission revoked", true);
        equal(2L, revoked.count(ImportRun.State.CANCELLED), "server stop prevents later writes");
        expect(IllegalArgumentException.class, () -> new ImportRun(List.of(entries.getFirst(), entries.getFirst())), "duplicate queue rejected");
    }

    private static void fileAndWorldMigration(Path root) throws Exception {
        Path source = Files.createDirectory(root.resolve("world-A"));
        Path target = Files.createDirectory(root.resolve("world-B"));
        String sourceContents = "# A\nflag true\ncommand 0\nnumber 5\n";
        String targetContents = "# B stays here\nflag false\nnumber 2\notherSetting keep\n";
        Files.writeString(source.resolve("carpet.conf"), sourceContents);
        Files.writeString(target.resolve("carpet.conf"), targetContents);
        List<RuleView> sourceRules = List.of(rule("carpet", "flag", "boolean", "true", false), command("0"),
                rule("carpet", "number", "int", "5", false));
        Path exported = root.resolve("carpet-world-A.txt");
        Files.writeString(exported, RuleConfigFile.format("World A", sourceRules, false));
        var document = RuleConfigFile.read(exported);
        List<RuleView> targetRules = List.of(rule("carpet", "flag", "boolean", "false", false), command("false"),
                rule("carpet", "number", "int", "2", false));
        ImportPlan plan = ImportPlan.create(document, targetRules, ImportPlan.Mode.ENABLED_ONLY);
        for (var entry : plan.ready()) WorldConfigStore.save(target, null, entry.manager(), entry.rule(), entry.value());
        equal(sourceContents, Files.readString(source.resolve("carpet.conf")), "source world untouched");
        String saved = Files.readString(target.resolve("carpet.conf"));
        require(saved.contains("flag true\n") && saved.contains("command 0\n"), "enabled values written into destination native config");
        require(saved.contains("number 2\n") && saved.contains("otherSetting keep\n") && saved.startsWith("# B stays here\n"),
                "enabled-only keeps numeric settings, unrelated rules and comments");
        for (var entry : ImportPlan.create(document, targetRules, ImportPlan.Mode.ALL_VALUES).ready())
            WorldConfigStore.save(target, null, entry.manager(), entry.rule(), entry.value());
        require(Files.readString(target.resolve("carpet.conf")).contains("number 5\n"), "all-values migration persists numeric setting");
        equal(sourceContents, Files.readString(source.resolve("carpet.conf")), "source still independent after all-values migration");
        Files.writeString(target.resolve("addon.conf"), "locked\nflag false\n");
        expect(IOException.class, () -> WorldConfigStore.save(target, null, "addon", "flag", "true"), "native lock enforced at write time");
        equal("locked\nflag false\n", Files.readString(target.resolve("addon.conf")), "locked config unchanged");
        Path invalidUtf8 = root.resolve("invalid.txt");
        Files.write(invalidUtf8, new byte[]{(byte) 0xc3, (byte) 0x28});
        expect(IOException.class, () -> RuleConfigFile.read(invalidUtf8), "malformed UTF-8 rejected");
        Path oversized = root.resolve("oversized.txt");
        Files.write(oversized, new byte[RuleConfigFile.MAX_FILE_BYTES + 1]);
        expect(IOException.class, () -> RuleConfigFile.read(oversized), "bounded file read");
        expect(IOException.class, () -> RuleConfigFile.read(root), "directory rejected");
        expect(IOException.class, () -> RuleConfigFile.read(root.resolve("missing.txt")), "missing file reported");
    }

    private static RuleView rule(String manager, String name, String type, String value, boolean locked) {
        return new RuleView(manager, manager, name, "", List.of(), List.of("true", "false"), type, false, value, "false", locked);
    }
    private static RuleView command(String value) {
        return new RuleView("carpet", "carpet", "command", "", List.of("command"), List.of("true", "false", "ops", "0"),
                "String", true, value, "false", false);
    }
    private static void equal(Object expected, Object actual, String label) { require(expected.equals(actual), label + ": " + actual); }
    private static void require(boolean value, String label) { if (!value) throw new AssertionError(label); checks++; }
    @FunctionalInterface private interface Checked { void run() throws Exception; }
    private static void expect(Class<? extends Exception> type, Checked action, String label) throws Exception {
        try { action.run(); }
        catch (Exception exception) {
            if (!type.isInstance(exception)) throw new AssertionError(label, exception);
            checks++; return;
        }
        throw new AssertionError(label + ": no exception");
    }
}
