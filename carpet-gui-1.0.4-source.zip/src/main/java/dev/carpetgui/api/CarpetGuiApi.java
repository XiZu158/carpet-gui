package dev.carpetgui.api;

import carpet.api.settings.SettingsManager;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Supplier;

/** Optional bridge for managers not returned by CarpetServer.forEachManager. */
public final class CarpetGuiApi {
    private static final List<Supplier<? extends SettingsManager>> PROVIDERS = new CopyOnWriteArrayList<>();

    /**
     * Register once during your extension's initialization. The supplier is evaluated on the
     * server thread for each snapshot. Return null while unavailable. Your extension remains
     * responsible for attaching/detaching the manager and loading its native world configuration.
     */
    public static void registerManager(Supplier<? extends SettingsManager> provider) {
        PROVIDERS.add(Objects.requireNonNull(provider));
    }

    public static List<SettingsManager> additionalManagers() {
        return PROVIDERS.stream().map(Supplier::get).filter(Objects::nonNull)
                .map(manager -> (SettingsManager) manager).toList();
    }
    private CarpetGuiApi() {}
}
