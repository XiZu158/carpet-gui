package dev.carpetgui.model;

import java.util.Set;

/** Classifies activity from explicit rule semantics instead of numeric guesses. */
public final class RuleActivity {
    private static final Set<String> ENABLED_COMMAND_LEVELS = Set.of("true", "ops", "0", "1", "2", "3", "4");

    private RuleActivity() {}

    /**
     * Boolean rules are enabled exactly when true. String command-permission rules
     * advertise a false option; their known active values include permission level
     * zero. Other strings, enums and numbers have no inferred on/off meaning.
     */
    public static boolean isEnabled(RuleView rule) {
        return isEnabledValue(rule, rule.value());
    }

    public static boolean isEnabledValue(RuleView rule, String value) {
        if ("boolean".equalsIgnoreCase(rule.type()) || "bool".equalsIgnoreCase(rule.type())) {
            return "true".equalsIgnoreCase(value);
        }
        if (!"String".equalsIgnoreCase(rule.type())
                || !rule.categories().contains("command")
                || !rule.options().contains("false")) {
            return false;
        }
        return ENABLED_COMMAND_LEVELS.contains(value);
    }

    /** A modified rule may be disabled, and an enabled rule may equal its default. */
    public static boolean isModified(RuleView rule) {
        return !rule.value().equals(rule.defaultValue());
    }
}
