package dev.carpetgui.model;

import java.util.List;

/** Standalone activity-filter checks, independent of Minecraft and JUnit. */
public final class RuleActivityTest {
    private static int checks;

    public static void main(String[] args) {
        for (String type : List.of("boolean", "Boolean", "bool")) {
            RuleView defaultEnabled = rule(type, "true", "true", List.of("custom-extension"), List.of("true", "false"));
            equal(true, RuleActivity.isEnabled(defaultEnabled), type + " default true remains enabled");
            equal(false, RuleActivity.isModified(defaultEnabled), type + " default true is not modified");

            RuleView changedOff = rule(type, "false", "true", List.of("custom-extension"), List.of("true", "false"));
            equal(false, RuleActivity.isEnabled(changedOff), type + " changed false is disabled");
            equal(true, RuleActivity.isModified(changedOff), type + " changed false remains modified");
        }

        for (String value : List.of("true", "ops", "0", "1", "2", "3", "4")) {
            RuleView command = rule("String", value, "false", List.of("command"), List.of("true", "false", "ops"));
            equal(true, RuleActivity.isEnabled(command), "command permission " + value + " is enabled");
            equal(true, RuleActivity.isModified(command), "command permission " + value + " differs from false");
        }

        RuleView commandOff = rule("String", "false", "ops", List.of("command"), List.of("false", "ops"));
        equal(false, RuleActivity.isEnabled(commandOff), "false command permission is disabled");
        equal(true, RuleActivity.isModified(commandOff), "disabled command permission can be modified");
        for (String value : List.of("5", "-1", "custom", "all", "")) {
            equal(false, RuleActivity.isEnabled(rule("String", value, value,
                    List.of("command"), List.of("false", value))), "unknown command permission is not guessed: " + value);
        }

        equal(false, RuleActivity.isEnabled(rule("String", "true", "false", List.of("feature"),
                List.of("true", "false"))), "ordinary string is not a boolean");
        equal(false, RuleActivity.isEnabled(rule("String", "ops", "ops", List.of("command"),
                List.of("ops", "true"))), "command rule needs an explicit false option");
        equal(false, RuleActivity.isEnabled(rule("Mode", "true", "false", List.of("feature"),
                List.of("true", "false"))), "enum named true is not enabled");
        equal(false, RuleActivity.isEnabled(rule("Mode", "true", "false", List.of("command"),
                List.of("true", "false"))), "command enum is not a String permission rule");

        for (String type : List.of("int", "Integer", "double", "Double", "long", "float")) {
            for (String value : List.of("0", "1", "4", "42")) {
                equal(false, RuleActivity.isEnabled(rule(type, value, "0", List.of("command"),
                        List.of("false", "0", "1", "4"))), type + " parameter " + value + " is not guessed");
            }
        }

        equal(true, RuleActivity.isModified(rule("double", "1.0", "1", List.of(), List.of())),
                "modified compares exact serialized values");
        equal(false, RuleActivity.isModified(rule("String", "", "", List.of(), List.of())), "equal empty strings unchanged");
        equal(true, RuleActivity.isEnabled(rule("boolean", "true", "false", List.of(), List.of())),
                "boolean classification does not require a category or options");

        System.out.println("RuleActivityTest: " + checks + " checks passed.");
    }

    private static RuleView rule(String type, String value, String defaultValue,
                                 List<String> categories, List<String> options) {
        return new RuleView("extension", "Extension", "example", "Example rule", categories, options,
                type, false, value, defaultValue, false);
    }

    private static void equal(boolean expected, boolean actual, String description) {
        if (expected != actual) throw new AssertionError(description + ": expected " + expected + ", got " + actual);
        checks++;
    }
}
