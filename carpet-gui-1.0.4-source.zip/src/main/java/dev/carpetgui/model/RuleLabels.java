package dev.carpetgui.model;

import java.util.function.Function;

/** Display labels are separate from the stable identifiers used by the protocol and config files. */
public final class RuleLabels {
    private RuleLabels() {}

    public static String name(RuleView rule, Function<String, String> translations) {
        String label = translated(rule.manager() + ".rule." + rule.name() + ".name", translations);
        return label == null ? rule.name() : label;
    }

    public static String category(String manager, String category, Function<String, String> translations) {
        String label = translated(manager + ".category." + category, translations);
        if (label == null && !"carpet".equals(manager)) {
            label = translated("carpet.category." + category, translations);
        }
        return label == null ? category : label;
    }

    private static String translated(String key, Function<String, String> translations) {
        String value = translations.apply(key);
        return value == null || value.isBlank() || value.equals(key) ? null : value;
    }
}
