package dev.carpetgui.network;

import com.google.gson.Gson;
import dev.carpetgui.CarpetGui;
import io.netty.buffer.Unpooled;
import io.netty.handler.codec.DecoderException;
import io.netty.handler.codec.EncoderException;
import net.fabricmc.fabric.impl.networking.PayloadTypeRegistryImpl;
import net.minecraft.core.RegistryAccess;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;

/** Reproduces the PCL-reported startup path using the actual packaged mod and runtime APIs. */
public final class GuiProtocolTest {
    private static int checks;

    public static void main(String[] args) {
        // The 1.0.0 build throws ExceptionInInitializerError here, before a window can open.
        GuiProtocol.register();
        equal("carpet_gui:request_v1", GuiProtocol.Request.TYPE.id().toString(), "request channel");
        equal("carpet_gui:response_v1", GuiProtocol.Response.TYPE.id().toString(), "response channel");
        equal(GuiProtocol.Request.TYPE,
                PayloadTypeRegistryImpl.SERVERBOUND_PLAY.get(GuiProtocol.Request.TYPE).type(), "registered request");
        equal(GuiProtocol.Response.TYPE,
                PayloadTypeRegistryImpl.CLIENTBOUND_PLAY.get(GuiProtocol.Response.TYPE).type(), "registered response");

        roundTrip(GuiProtocol.Request.CODEC, new GuiProtocol.Request(1, "snapshot", "", "", ""));
        roundTrip(GuiProtocol.Request.CODEC, new GuiProtocol.Request(2, "set", "extension", "aRule", "中文 value"));
        roundTrip(GuiProtocol.Request.CODEC, new GuiProtocol.Request(7, GuiProtocol.IMPORT_ACTION, "carpet", "aRule", "true"));
        Gson gson = new Gson();
        var saved = new GuiProtocol.ImportReply(GuiProtocol.IMPORT_ACTION, true, false, "carpet", "aRule", "normalized", "已保存");
        roundTrip(GuiProtocol.Response.CODEC, new GuiProtocol.Response(7, gson.toJson(saved)));
        equal(saved, gson.fromJson(gson.toJson(saved), GuiProtocol.ImportReply.class), "structured success acknowledgement");
        var denied = new GuiProtocol.ImportReply(GuiProtocol.IMPORT_ACTION, false, true, "carpet", "aRule", "", "权限已撤销");
        equal(denied, gson.fromJson(gson.toJson(denied), GuiProtocol.ImportReply.class), "structured stop acknowledgement");
        var snapshot = new CarpetGui.SnapshotPage("world", true, "", false, 0, 1, java.util.List.of(), GuiProtocol.TRANSFER_VERSION);
        equal(GuiProtocol.TRANSFER_VERSION, gson.fromJson(gson.toJson(snapshot), CarpetGui.SnapshotPage.class).transferVersion(), "import capability advertised");
        equal(0, gson.fromJson("{\"world\":\"old server\",\"canEdit\":true}", CarpetGui.SnapshotPage.class).transferVersion(), "old server does not advertise import");
        roundTrip(GuiProtocol.Request.CODEC,
                new GuiProtocol.Request(3, "set", "carpet", "aRule", "值".repeat(GuiProtocol.MAX_VALUE_LENGTH)));
        roundTrip(GuiProtocol.Response.CODEC,
                new GuiProtocol.Response(1, "{\"world\":\"世界 A\",\"message\":\"已读取\",\"rules\":[]}"));
        roundTrip(GuiProtocol.Response.CODEC,
                new GuiProtocol.Response(4, "x".repeat(GuiProtocol.MAX_JSON_LENGTH)));

        RegistryFriendlyByteBuf buffer = buffer();
        try {
            expect(EncoderException.class, () -> GuiProtocol.Request.CODEC.encode(buffer,
                    new GuiProtocol.Request(5, "set", "carpet", "aRule", "x".repeat(GuiProtocol.MAX_VALUE_LENGTH + 1))),
                    "reject overlong request on encode");
            buffer.clear();
            buffer.writeVarInt(6);
            buffer.writeUtf("set");
            buffer.writeUtf("carpet");
            buffer.writeUtf("aRule");
            buffer.writeUtf("x".repeat(GuiProtocol.MAX_VALUE_LENGTH + 1), GuiProtocol.MAX_VALUE_LENGTH + 1);
            expect(DecoderException.class, () -> GuiProtocol.Request.CODEC.decode(buffer),
                    "reject overlong request on decode");
        } finally {
            buffer.release();
        }
        System.out.println("GuiProtocolTest: " + checks + " checks passed (packaged JAR, real Minecraft/Fabric registration and codecs).");
    }

    private static RegistryFriendlyByteBuf buffer() {
        return new RegistryFriendlyByteBuf(Unpooled.buffer(), RegistryAccess.EMPTY);
    }

    private static <T> void roundTrip(StreamCodec<RegistryFriendlyByteBuf, T> codec, T expected) {
        RegistryFriendlyByteBuf buffer = buffer();
        try {
            codec.encode(buffer, expected);
            equal(expected, codec.decode(buffer), "payload round trip");
            equal(0, buffer.readableBytes(), "payload fully consumed");
        } finally {
            buffer.release();
        }
    }

    private static void expect(Class<? extends RuntimeException> type, Runnable action, String label) {
        try {
            action.run();
        } catch (RuntimeException exception) {
            if (!type.isInstance(exception)) throw new AssertionError(label, exception);
            checks++;
            return;
        }
        throw new AssertionError(label + ": no exception");
    }

    private static void equal(Object expected, Object actual, String label) {
        if (!expected.equals(actual)) throw new AssertionError(label + ": expected " + expected + ", got " + actual);
        checks++;
    }
}
